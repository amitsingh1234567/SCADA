import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AdminComponent } from "./admin.component";
import { MaterialModule } from "./material.module";
import { AdminService } from "./admin.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";


// import {MatStepperModule} from '@angular/material/stepper';
// import {MatSelectModule} from '@angular/material/select';
// import { MatInputModule } from "@angular/material/input";

@NgModule({
    declarations: [AdminComponent],
    imports: [
        CommonModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule
    ],
    providers:[AdminService]
})

export class AdminModule {};