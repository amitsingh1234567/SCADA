import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { from, of } from "rxjs";
import { AdminService } from './admin.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

export interface InformationTableData {
  item: string,
  value: any
}
const information1: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]
const information2: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]
const information3: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]
const information4: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]
const information5: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]
const information6: InformationTableData[] = [
  { item: 'Request count', value: null },
  { item: 'Last communication', value: null },
  { item: 'Status', value: null },
  { item: 'Model No', value: null },
  { item: 'Serial No', value: null },
  { item: 'Total device connected', value: null }
]

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AdminComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  columns: string[] = ['S.no', 'TimeStamp', 'Request', 'Data'];
  infoColumns: string[] = ['item', 'value'];
  // dataSource2 = information;
  data: any;
  plantProfile: any
  date

  isActiveStringInverter = false;
  isActiveCentralizedInverter = false;
  isActiveWeatherStation = false;
  isActiveMeter = false;
  isActiveDieselGenerator = false;
  isActiveDataLogger = false;

  stringInverter2
  centralizedInverter2
  weatherStation2
  meter2
  dieselGenerator2
  dataLogger2

  stringInverterInfo = information1
  centralizedInverterInfo = information2
  weatherStationInfo = information3
  meterInfo = information4
  dieselGeneratorInfo = information5
  DLogInfo = information6

  stringInverterDataSource;
  centralizedInverterDataSource;
  weatherStationDataSource;
  meterDataSource;
  dieselGeneratorDataSource;
  DLogDataSource;


  constructor(private adminService: AdminService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.fetchData();
    this.date = new FormControl(new Date());
    this.snackBar('Please select site name to see data', 4000);
  }

  snackBar(message, duration) {
    this._snackBar.open(message, 'End now', {
      duration: duration,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }

  fetchData() {
    this.adminService.getData().subscribe(res => {
      this.data = res.data;
      this.plantProfile = res.data
    })
  }



  onClick(id: any) {
    this.stringInverterDataSource = null;
    this.centralizedInverterDataSource = null;
    this.weatherStationDataSource = null;
    this.meterDataSource = null;
    this.dieselGeneratorDataSource = null;
    this.DLogDataSource = null;

    for(let i = 0; i <= 5; i++){
      this.stringInverterInfo[i].value = null;
      this.centralizedInverterInfo[i].value = null;
      this.weatherStationInfo[i].value = null;
      this.meterInfo[i].value = null;
      this.dieselGeneratorInfo[i].value = null;
      this.DLogInfo[i].value = null;
    }
    
    this.adminService.getIdData(id).subscribe(res => {
      this.isActiveStringInverter = res.data.stringInverter.isActive;
      this.isActiveCentralizedInverter = res.data.centralizedInverter.isActive;
      this.isActiveWeatherStation = res.data.weatherStation.isActive;
      this.isActiveMeter = res.data.meter.isActive;
      this.isActiveDieselGenerator = res.data.dieselGenerator.isActive;
      this.isActiveDataLogger = res.data.dataLogger.isActive;
      if (!this.isActiveStringInverter && !this.isActiveCentralizedInverter && !this.isActiveWeatherStation && !this.isActiveMeter && !this.isActiveDieselGenerator && !this.isActiveDataLogger) {
        this.snackBar('No data to display', 2000);
        return;
      }

      if (this.isActiveStringInverter) {
        this.stringInverter2 = res.data.stringInverter.details;
      }
      if (this.isActiveCentralizedInverter) {
        this.centralizedInverter2 = res.data.centralizedInverter.details;
      }
      if (this.isActiveWeatherStation) {
        this.weatherStation2 = res.data.weatherStation.details;
      }
      if (this.isActiveMeter) {
        this.meter2 = res.data.meter.details;
      }
      if (this.isActiveDieselGenerator) {
        this.dieselGenerator2 = res.data.dieselGenerator.details;
      }
      if (this.isActiveDataLogger) {
        this.dataLogger2 = res.data.dataLogger.details;
      }

    })
  }


  filterData(res, infoTable) {
    var arr = [];
    res.data.data.forEach((item, index) => {
      arr.push({
        SrNo: index + 1,
        timeStamp: res.data.date,
        request: `${res.data.request.loggerNo}, ${res.data.request.plantId}, ${res.data.request.deviceType}, ${res.data.request.deviceNo}, ${res.data.request.errorFlag}`,
        data: item
      })
    });

    infoTable[0].value = res.data.information.requestCount;
    infoTable[1].value = res.data.information.lastCommunication;
    infoTable[2].value = res.data.information.status;
    infoTable[3].value = res.data.information.modelNo;
    infoTable[4].value = res.data.information.serialNo;
    infoTable[5].value = res.data.information.totalDeviceConnected;
    return arr;
  }

  onStringInverterAction(deviceName, deviceNo) {
    this.adminService.getDataOnPortal(deviceNo + 1).subscribe(res => {
      console.log(res)
      this.stringInverterDataSource = this.filterData(res, this.stringInverterInfo);
    })
  }

  onDLOGAction(deviceName, deviceNo) {
    this.adminService.getDataOnPortal(deviceNo + 1).subscribe(res => {
      this.DLogDataSource = this.filterData(res, this.DLogInfo);
    })
  }
}

