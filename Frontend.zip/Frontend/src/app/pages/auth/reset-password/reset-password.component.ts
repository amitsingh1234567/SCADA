import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  token;
  loader = false;
  constructor(private route: ActivatedRoute, public router: Router, private _snackBar: MatSnackBar, private authService: AuthService) { }

  ngOnInit() {
  this.token = this.route.snapshot.paramMap.get('token');
  }

  resetPassword(pswd: NgForm){
    const {password, ConfPassword } = pswd.value;

    if(!password || !ConfPassword){
      return this.snackBar("Please fill the input field", 4000);
    }

    if(password != ConfPassword){
      return this.snackBar("Password does not match", 4000);
    }

    this.loader = true;
    this.authService.resetPassword(password, this.token).subscribe(res => {
      if(!res.success){
      this.snackBar(res.message, 4000);
      this.loader = false;
      return;
      }

      this.snackBar(res.message, 4000);
      this.loader = false;
      this.router.navigate(['/login']);
    })
  }
  snackBar(message, duration) {
    this._snackBar.open(message, 'End now', {
      duration: duration,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }
}
