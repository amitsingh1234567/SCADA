import { Component, OnInit, OnDestroy } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Subscription } from 'rxjs';
import { Router } from "@angular/router";

import { AuthService } from '../auth.service';

@Component({
  selector: "app-login",
  templateUrl: "login.component.html",
  styleUrls:['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  test: Date = new Date();
  isLoading = false;
  isCollapsed = true;
  isAuthenticated = false;
  private authStatusSub:Subscription;

  constructor( public authService:AuthService, private router: Router) {}

  ngOnInit() {
    this.isAuthenticated = this.authService.getIsAuthenticated();
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }
    )
  }

  onLogin(form: NgForm) {
    if(form.invalid){
      return;
    }
    this.isLoading = true;
    this.authService.login(form.value.email, form.value.password)
  }

  resetPassword(){
    this.router.navigate(['/reset-password']);
    // console.log('--------- Reset')
    // this.authService.resetPassword('test@gmail.com')
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe;
  }
}
