import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { AuthService } from '../auth.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  resetPswd = true;
  completeReset = false;
  message;
  host;
  loader = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(private authService: AuthService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
   this.host = window.location.href;
  }

  forgetPassword(email: NgForm) {
    if (!email.value.email) {
      return this.snackBar('Please fill the input field', 4000);
    }
    this.loader = true;
    this.authService.forgetPassword(email.value.email, this.host).subscribe(res => {
      if (!res.success) {
          this.loader = false;
          return  this.snackBar(res.message, 4000);
      }
      this.loader = false;
      this.message = res.message;
      this.resetPswd = false;
      this.completeReset = true;
    })
  }

  snackBar(message, duration) {
    this._snackBar.open(message, 'End now', {
      duration: duration,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition
    });
  }
}
