import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';

export interface dieselGenerator {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-diesel-generator',
  templateUrl: './diesel-generator.component.html',
  styleUrls: ['./diesel-generator.component.scss']
})
export class DieselGeneratorComponent implements OnInit {
  btnText = 'Submit';
  warningTxt;
  dieselGeneratorForm: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public data: dieselGenerator, public dialogRef: MatDialogRef<DieselGeneratorComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.dieselGeneratorForm = new FormGroup({
      name: new FormControl(),
      capacity: new FormControl()
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const {name, capacity } = this.data.value;
      this.dieselGeneratorForm.setValue({
        name: name,
       capacity: capacity       
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.dieselGeneratorForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.dieselGeneratorForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
