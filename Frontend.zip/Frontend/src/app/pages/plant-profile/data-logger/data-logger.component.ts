import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';

export interface dataLogger {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-data-logger',
  templateUrl: './data-logger.component.html',
  styleUrls: ['./data-logger.component.scss']
})
export class DataLoggerComponent implements OnInit {
  btnText = 'Submit';
  warningTxt;
  dataLoggerForm: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public data: dataLogger, public dialogRef: MatDialogRef<DataLoggerComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.dataLoggerForm = new FormGroup({
      name: new FormControl(),
      make: new FormControl(),
      modelNo: new FormControl(),
      serialNo: new FormControl(),
      building: new FormControl(),
      deviceConnected: new FormControl()
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const {name, make, modelNo, building, serialNo, deviceConnected } = this.data.value;
      this.dataLoggerForm.setValue({
        name: name,
        make: make,
        modelNo: modelNo,
        serialNo: serialNo,
        building: building,
        deviceConnected: deviceConnected
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.dataLoggerForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.dataLoggerForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
