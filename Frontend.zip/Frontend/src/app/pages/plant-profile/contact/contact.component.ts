import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';


export interface Contact {
  action: string;
  index: number;
  number: string
}



@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  contactForm: FormGroup;
  updateRowValue = '';
  btnText;
  warningTxt
  constructor(@Inject(MAT_DIALOG_DATA) public data: Contact, public dialogRef: MatDialogRef<ContactComponent>) {
    if(data.action == 'Update'){
      this.updateRowValue = data.number;
      this.btnText = 'Update';
    }
    if(data.action == 'Add'){
      this.btnText = 'Submit';
    }
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete'
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete all Contact'
    }
   }

  ngOnInit() {
    this.contactForm = new FormGroup({
      contact: new FormControl(this.updateRowValue, [Validators.required])
    });
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.contactForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.contactForm.value.contact, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
