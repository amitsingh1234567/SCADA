import { Injectable } from "@angular/core"
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
import { Subject } from 'rxjs';


@Injectable({ providedIn: "root" })

export class PlantProfileService{

    constructor(public router: Router, private http:HttpClient){
     
    }

    nodeRedApi(){
      return this.http.get('http://localhost:1880/test?deviceType=INV-2&cmdType=1');
    }

    insert(data: Object){
       return this.http.post('http://localhost:3000/api/plantProfile/insert', data);
    }

    update(data: Object, id: string){
       return this.http.patch(`http://localhost:3000/api/plantProfile/update/${id}`, data);
    }

    delete(id){
       return this.http.delete(`http://localhost:3000/api/plantProfile/delete/${id}`);
    }

    getAllPlantProfile(){
       return this.http.get<{success: boolean, data: object}>('http://localhost:3000/api/plantProfile/all');
    }

    getPlantProfile(id: string){
        return this.http.get<{success: boolean, data: any}>(`http://localhost:3000/api/plantProfile/${id}`);
    }
}