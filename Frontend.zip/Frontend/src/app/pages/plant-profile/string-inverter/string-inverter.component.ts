import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { id } from '@swimlane/ngx-datatable';

export interface stringInverter {
  action: string;
  index: number;
  email: string;
  value: any;
}

@Component({
  selector: 'app-string-inverter',
  templateUrl: './string-inverter.component.html',
  styleUrls: ['./string-inverter.component.scss']
})

export class StringInverterComponent implements OnInit {

  btnText = 'Submit';
  warningTxt;
  stringInverterForm: FormGroup
  constructor(@Inject(MAT_DIALOG_DATA) public data: stringInverter, public dialogRef: MatDialogRef<StringInverterComponent>) { 
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.stringInverterForm = new FormGroup({
      id: new FormControl(),
      name: new FormControl(),
      make: new FormControl(),
      capacity: new FormControl(),
      modelNo: new FormControl(),
      building: new FormControl(),
      buildingType: new FormControl(),
      dataLoggerNo: new FormControl(),
      MPPT: new FormControl(),
      string: new FormControl()
    });
  };

  onUpdate(){
    if(this.data.action == 'Update'){
      const {name, make, capacity, modelNo, building, buildingType, dataLoggerNo, MPPT, string, id } = this.data.value;
      this.stringInverterForm.setValue({
        id: id,
        name: name,
        make: make,
        capacity: capacity,
        modelNo: modelNo,
        building: building,
        buildingType: buildingType,
        dataLoggerNo: dataLoggerNo,
        MPPT: MPPT,
        string: string
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.stringInverterForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.stringInverterForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
