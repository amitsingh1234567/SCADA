import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';


export interface Email {
  action: string;
  index: number;
  email: string
}


@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.scss']
})
export class EmailComponent implements OnInit {

  emailForm: FormGroup;
  updateRowValue = null;
  btnText;
  warningTxt;
  constructor(@Inject(MAT_DIALOG_DATA) public data: Email, public dialogRef: MatDialogRef<EmailComponent>) {
    // console.log(data)
    if(data.action == 'Add'){
      this.btnText = 'Submit';
    }
    if(data.action == 'Update'){
      this.updateRowValue = data.email;
      this.btnText = 'Update';
    }
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete'
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete all Email'
    }
  }

  ngOnInit() {
      this.emailForm = new FormGroup({
        email: new FormControl(this.updateRowValue, [Validators.required, Validators.email])
      });
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.emailForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.emailForm.value.email, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
