import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PlantProfileService } from '../plant-profile.service';

@Component({
  selector: 'app-update-plant-profile',
  templateUrl: './update-plant-profile.component.html',
  styleUrls: ['./update-plant-profile.component.scss']
})
export class UpdatePlantProfileComponent implements OnInit {
  plantProfile
  constructor(private plantProfileService: PlantProfileService, public router: Router) { }

  ngOnInit() {
    this.plantProfileService.getAllPlantProfile().subscribe(res => {
      this.plantProfile = res.data;
    });
  }

  onUpdate(id){
    this.router.navigate([`/update/plantProfile/${id}`]);
  }

  onDelete(id){
    this.plantProfileService.delete(id).subscribe(res =>{
      console.log(res)
    })
    
  }
}
