import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePlantProfileComponent } from './update-plant-profile.component';

describe('UpdatePlantProfileComponent', () => {
  let component: UpdatePlantProfileComponent;
  let fixture: ComponentFixture<UpdatePlantProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatePlantProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePlantProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
