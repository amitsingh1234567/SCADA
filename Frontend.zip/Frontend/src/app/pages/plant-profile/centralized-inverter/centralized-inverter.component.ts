import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { id } from '@swimlane/ngx-datatable';


export interface centralizedInverter {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-centralized-inverter',
  templateUrl: './centralized-inverter.component.html',
  styleUrls: ['./centralized-inverter.component.scss']
})
export class CentralizedInverterComponent implements OnInit {

  btnText = 'Submit';
  warningTxt;
  centralizedInverterForm: FormGroup

  constructor(@Inject(MAT_DIALOG_DATA) public data: centralizedInverter, public dialogRef: MatDialogRef<CentralizedInverterComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.centralizedInverterForm = new FormGroup({
      id: new FormControl(),
      name: new FormControl(),
      make: new FormControl(),
      capacity: new FormControl(),
      modelNo: new FormControl(),
      building: new FormControl(),
      buildingType: new FormControl(),
      dataLoggerNo: new FormControl(),
      unit: new FormControl()
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const { name, make, capacity, modelNo, building, buildingType, dataLoggerNo, unit, id } = this.data.value;
      this.centralizedInverterForm.setValue({
        id: id,
        name: name,
        make: make,
        capacity: capacity,
        modelNo: modelNo,
        building: building,
        buildingType: buildingType,
        dataLoggerNo: dataLoggerNo,
        unit: unit
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.centralizedInverterForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.centralizedInverterForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
