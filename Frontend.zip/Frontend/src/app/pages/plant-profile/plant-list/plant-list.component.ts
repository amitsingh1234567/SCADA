import { Component, OnInit } from '@angular/core';
import { PlantProfileService } from '../plant-profile.service';

@Component({
  selector: 'app-plant-list',
  templateUrl: './plant-list.component.html',
  styleUrls: ['./plant-list.component.scss']
})
export class PlantListComponent implements OnInit {

  constructor(private service: PlantProfileService) { }

  ngOnInit() {
  }
  callNodeRedApi(){
    console.log('--------> Node-Red Api')
    this.service.nodeRedApi().subscribe(console.log)
  }
}
