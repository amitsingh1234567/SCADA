import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';

export interface zeroExport {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-zero-export',
  templateUrl: './zero-export.component.html',
  styleUrls: ['./zero-export.component.scss']
})
export class ZeroExportComponent implements OnInit {
  btnText = 'Submit';
  warningTxt;
  zeroExportForm: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public data: zeroExport, public dialogRef: MatDialogRef<ZeroExportComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.zeroExportForm = new FormGroup({
      name: new FormControl()
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const { name } = this.data.value;
      this.zeroExportForm.setValue({
        name: name
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.zeroExportForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.zeroExportForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }
}
