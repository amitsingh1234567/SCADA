import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';

export interface Meter {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-meter',
  templateUrl: './meter.component.html',
  styleUrls: ['./meter.component.scss']
})
export class MeterComponent implements OnInit {
  btnText = 'Submit';
  warningTxt;
  meterForm: FormGroup;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Meter, public dialogRef: MatDialogRef<MeterComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.meterForm = new FormGroup({
      name: new FormControl(),
      make: new FormControl(),
      modelNo: new FormControl(),
      building: new FormControl(),
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const {name, make, modelNo, building } = this.data.value;
      this.meterForm.setValue({
        name: name,
        make: make,
        modelNo: modelNo,
        building: building,
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.meterForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.meterForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }

}
