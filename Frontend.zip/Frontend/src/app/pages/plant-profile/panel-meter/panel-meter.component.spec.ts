import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PanelMeterComponent } from './panel-meter.component';

describe('PanelMeterComponent', () => {
  let component: PanelMeterComponent;
  let fixture: ComponentFixture<PanelMeterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PanelMeterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelMeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
