import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormControl, FormGroup, Validators} from '@angular/forms';


export interface panelMeter {
  action: string;
  index: number;
  value: any;
}

@Component({
  selector: 'app-panel-meter',
  templateUrl: './panel-meter.component.html',
  styleUrls: ['./panel-meter.component.scss']
})
export class PanelMeterComponent implements OnInit {
  btnText = 'Submit';
  warningTxt;
  panelMeterForm: FormGroup;

    constructor(@Inject(MAT_DIALOG_DATA) public data: panelMeter, public dialogRef: MatDialogRef<PanelMeterComponent>) {     
    console.log(data)
    if(data.action == 'Delete'){
      this.warningTxt = 'Sure you want to delete';
    }
    if(data.action == 'DeleteAll'){
      this.warningTxt = 'Sure you want to delete All';
    }
  }

  ngOnInit() {
    this.Form();
    this.onUpdate();
  }

  Form(){
    this.panelMeterForm = new FormGroup({
      name: new FormControl(),
      make: new FormControl(),
      modelNo: new FormControl(),
      solution: new FormControl(),
    });
  }

  onUpdate(){
    if(this.data.action == 'Update'){
      const {name, make, modelNo, solution } = this.data.value;
      this.panelMeterForm.setValue({
        name: name,
        make: make,
        modelNo: modelNo,
        solution: solution
      })
      this.btnText = 'Update';
    }
  }

  onCancel(){
    this.dialogRef.close({event: 'Cancel'});
  }

  onSubmit(){
    if(this.data.action == 'Add' || this.data.action == 'Update'){
    if(!this.panelMeterForm.valid)
    return;
    this.dialogRef.close({event:this.data.action, data: this.panelMeterForm.value, index: this.data.index});
    }else{
      this.dialogRef.close({event:this.data.action, index: this.data.index});
    }
  }
}
