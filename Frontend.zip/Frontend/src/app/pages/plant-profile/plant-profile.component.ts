import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatRadioChange } from '@angular/material/radio';
import { EmailComponent } from './email/email.component';
import { MatTable } from '@angular/material/table';
import { ContactComponent } from './contact/contact.component';
import { PlantProfileService } from './plant-profile.service';
import { StringInverterComponent } from './string-inverter/string-inverter.component';
import { Email, Contact, stringInverter, centralizedInverter, Meter, panelMeter, dieselGenerator, zeroExport, dataLogger } from './plant-profile.model';
import { CentralizedInverterComponent } from './centralized-inverter/centralized-inverter.component';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MeterComponent } from './meter/meter.component';
import { PanelMeterComponent } from './panel-meter/panel-meter.component';
import { DieselGeneratorComponent } from './diesel-generator/diesel-generator.component';
import { ZeroExportComponent } from './zero-export/zero-export.component';
import { DataLoggerComponent } from './data-logger/data-logger.component';

const EMAIL: Email[] = [];
const CONTACT_NUMBER: Contact[] = [];
const STRING_INVERTER: stringInverter[] = [];
const CENTRALIZED_INVERTER: centralizedInverter[] = [];
const METER: Meter[] = [];
const PANEL_METER: panelMeter[] = [];
const DIESEL_GENERATOR: dieselGenerator[] = [];
const ZERO_EXPORT: zeroExport[] = [];
const DATA_LOGGER: dataLogger[] = [];

@Component({
  selector: 'app-plant-profile',
  templateUrl: './plant-profile.component.html',
  styleUrls: ['./plant-profile.component.scss']
})
export class PlantProfileComponent implements OnInit {

  plantProfileForm: FormGroup;

  email = "No";
  contact = "No";
  stringInverter = "No";
  centralizedInverter = "No";
  meter = "No";
  panelMeter = "No";
  dieselGenerator = "No";
  zeroExport = "No";
  dataLogger = "No";

  isEmail = false;
  isContact = false;
  isStringInverter = false;
  isCentralizedInverter = false;
  isMeter = false;
  isPanelMeter = false;
  isDieselGenerator = false;
  isZeroExport = false;
  isDataLogger = false;

  emailColumns: string[] = ['email', 'action'];
  contactColumns: string[] = ['number', 'action'];
  stringInverterColumns: string[] = ['id', 'name', 'capacity', 'action'];
  centralizedInverterColumns: string[] = ['id', 'name', 'capacity', 'action'];
  meterColumns: string[] = ['name', 'make', 'action'];
  panelMeterColumns: string[] = ['name', 'make', 'action'];
  dieselGeneratorColumns: string[] = ['name', 'capacity', 'action'];
  zeroExportColumns: string[] = ['name', 'capacity', 'action'];
  dataLoggerColumns: string[] = ['name', 'capacity', 'action'];

  emailDataSource = EMAIL;
  contactDataSource = CONTACT_NUMBER;
  stringInverterDataSource = STRING_INVERTER;
  centralizedInverterDataSource = CENTRALIZED_INVERTER;
  meterDataSource = METER;
  panelMeterDataSource = PANEL_METER;
  dieselGeneratorDataSource = DIESEL_GENERATOR;
  zeroExportDataSource = ZERO_EXPORT;
  dataLoggerDataSource = DATA_LOGGER;

  mode: string;
  id: string;
  @ViewChild('emailTable') emailTable: MatTable<any>;
  @ViewChild('contactTable') contactTable: MatTable<any>;
  @ViewChild('stringInverterTable') stringInverterTable: MatTable<any>;
  @ViewChild('centralizedInverterTable') centralizedInverterTable: MatTable<any>;
  @ViewChild('meterTable') meterTable: MatTable<any>;
  @ViewChild('panelMeterTable') panelMeterTable: MatTable<any>;
  @ViewChild('dieselGeneratorTable') dieselGeneratorTable: MatTable<any>;
  @ViewChild('zeroExportTable') zeroExportTable: MatTable<any>;
  @ViewChild('dataLoggerTable') dataLoggerTable: MatTable<any>;

  constructor(public dialog: MatDialog, private plantProfileService: PlantProfileService, public route: ActivatedRoute) { };

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('id')) {
        this.mode = 'Update';
        this.id = paramMap.get('id');
        this.plantProfileService.getPlantProfile(this.id).subscribe(res => {
          console.log(res)
          this.onUpdate(res);
        });
      } else {
        this.mode = 'Create';
      }
    });

    this.Form();
  };

  Form() {
    this.plantProfileForm = new FormGroup({
      plantId: new FormControl(),
      plantName: new FormControl(),
      // email: new FormControl(null, [Validators.required, Validators.email]),
      address: new FormGroup({
        location: new FormControl(),
        lat: new FormControl(),
        long: new FormControl()
      }),
      owner: new FormControl(),
      commissioningDate: new FormControl(),
      licenseExpiryDate: new FormControl(),
      unitPrice: new FormControl(),
      plantCapacity: new FormControl(),
      PVModules: new FormGroup({
        quantity: new FormControl(),
        make: new FormControl(),
        wattage: new FormControl()
      })
    });
  }

  onUpdate(res: any) {
    if (res.data.emailId.isActive) {
      this.email = 'Yes';
      this.isEmail = true;
      this.emailDataSource = res.data.emailId.details;
    } else {
      this.email = 'No';
    }

    if (res.data.mobileNo.isActive) {
      this.contact = 'Yes';
      this.isContact = true;
      this.contactDataSource = res.data.mobileNo.details;
    } else {
      this.contact = 'No';
    }

    if(res.data.stringInverter.isActive){
      this.stringInverter = 'Yes';
      this.isStringInverter = true;
      this.stringInverterDataSource = res.data.stringInverter.details;
    }else{
      this.stringInverter = 'No';
    }

    if(res.data.centralizedInverter.isActive){
      this.centralizedInverter = 'Yes';
      this.isCentralizedInverter = true;
      this.centralizedInverterDataSource = res.data.centralizedInverter.details;
    }else{
      this.centralizedInverter = 'No';
    }

    this.plantProfileForm.setValue({
      plantId: res.data.plantId,
      plantName: res.data.plantName,
      address: {
        location: res.data.location.name,
        lat: res.data.location.coordinates[0],
        long: res.data.location.coordinates[1]
      },
      owner: res.data.owner,
      commissioningDate: res.data.commissioningDate.date,
      licenseExpiryDate: res.data.licenseExpiryDate.date,
      unitPrice: res.data.unitPrice,
      plantCapacity: res.data.plantCapacity,
      PVModules: {
        quantity: res.data.PVModules.quantity,
        make: res.data.PVModules.make,
        wattage: res.data.PVModules.wattage
      }
    })
  }

  onSubmit() {
    // console.log(this.plantProfileForm.value)
    let stringInverter;
    let centralizedInverter;
    // delete this.emailDataSource[0].edit;
    // delete this.emailDataSource[0].delete;
    // return
    this.plantProfileForm.value.commissioningDate = this.plantProfileForm.value.commissioningDate._d;
    this.plantProfileForm.value.licenseExpiryDate = this.plantProfileForm.value.licenseExpiryDate._d;

    if (this.emailDataSource.length != 0) {
      // let emailDataSource =  [];
      // this.emailDataSource.forEach((value, index) => {
      //   // emailDataSource.push({id: index+1, email: value.email});
      // });

      this.plantProfileForm.value.emailId = {};
      this.plantProfileForm.value.emailId.isActive = true;
      this.plantProfileForm.value.emailId.details = this.emailDataSource;

    } else {
      this.plantProfileForm.value.emailId = {};
      this.plantProfileForm.value.emailId.isActive = false;
      this.plantProfileForm.value.emailId.details = [];
    }

    if (this.contactDataSource.length != 0) {
      // let contactDataSource =  [];
      // this.contactDataSource.forEach((value, index) => {
      //   contactDataSource.push({id: index+1, contact: value.contact});
      // })
      this.plantProfileForm.value.mobileNo = {};
      this.plantProfileForm.value.mobileNo.isActive = true;
      this.plantProfileForm.value.mobileNo.details = this.contactDataSource;
    } else {
      this.plantProfileForm.value.mobileNo = {};
      this.plantProfileForm.value.mobileNo.isActive = false;
      this.plantProfileForm.value.mobileNo.details = [];
    }

    if (this.stringInverterDataSource.length != 0) {
      stringInverter = {
        isActive: true,
        quantity: this.stringInverterDataSource.length,
        details: this.stringInverterDataSource
      }
    } else {
      stringInverter = {
        isActive: false,
        quantity: this.stringInverterDataSource.length,
        details: this.stringInverterDataSource
      }
    }

    if (this.centralizedInverterDataSource.length != 0) {
      centralizedInverter = {
        isActive: true,
        quantity: this.centralizedInverterDataSource.length,
        details: this.centralizedInverterDataSource
      }
    } else {
      centralizedInverter = {
        isActive: false,
        quantity: this.centralizedInverterDataSource.length,
        details: this.centralizedInverterDataSource
      }
    }

    // Appending Dialog Box Data
    let data = this.plantProfileForm.value;
    data.stringInverter = stringInverter;
    data.centralizedInverter = centralizedInverter;

    if (this.mode == 'Create') {
      this.plantProfileService.insert(data).subscribe(res => {
        console.log(res)
      })
    }

    if (this.mode == 'Update') {
      this.plantProfileService.update(data, this.id).subscribe(res => {
        console.log(res)
      })
    }

  }

  customizeDialogBox(action: string) {
    let Width: string;
    let Height: string;
    let Top: string;

    if (action == 'Delete' || action == 'DeleteAll') {
      Width = '400px';
      Height = '130px';
      Top = '200px';
      return { width: Width, height: Height, top: Top };
    } else {
      Width = '650px';
      Height = '440px';
      Top = '80px';
      return { width: Width, height: Height, top: Top };
    }
  }

  emailDialog(action: string, obj: any) {
    obj.action = action;
    let emailComp = this.dialog.open(EmailComponent, {
      data: obj,
      width: '400px',
      position: {
        top: '150px'
      }
    });
    emailComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.emailDataSource.length != 0) {
          this.email = 'Yes';
        } else {
          this.email = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_Email(res.data);
      if (res.event == 'Update')
        this.update_Email(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_Email(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_Email();
    });
  }

  onEmailOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.emailDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.emailDataSource.length != 0)
        this.emailDialog('DeleteAll', {});
    }
  };

  add_Email(data) {
    this.isEmail = true;
    this.emailDataSource.push({ email: data, edit: 'Edit', delete: 'Delete' });
    if (this.emailDataSource.length != 1) {
      this.emailTable.renderRows();
    }
  }

  update_Email(data, tableRowId) {
    this.emailDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
        value.email = data;
      }
    })
  }

  delete_Email(tableRowId) {
    this.emailDataSource = this.emailDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.emailDataSource.length == 0) {
      // this.emailOpt = new FormControl('No');
      this.email = 'No'
      this.isEmail = false;
    }
  }

  deleteAll_Email() {
    if (this.emailDataSource.length != 0) {
      this.emailDataSource.splice(0, this.emailDataSource.length);
      this.isEmail = false;
    }
  }

  /******** Contact Section ******/

  contactDialog(action: string, obj: any) {
    obj.action = action;
    let contactComp = this.dialog.open(ContactComponent, {
      data: obj,
      width: '400px',
      position: {
        top: '150px'
      }
    });
    contactComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.contactDataSource.length != 0) {
          this.contact = 'Yes';
        } else {
          this.contact = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_Contact(res.data);
      if (res.event == 'Update')
        this.update_Contact(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_Contact(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_Contact();
    });
  }

  onContactOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.contactDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.contactDataSource.length != 0)
        this.contactDialog('DeleteAll', {});
    }
  }

  add_Contact(data) {
    this.isContact = true;
    this.contactDataSource.push({ contact: data, edit: 'Edit', delete: 'Delete' });
    if (this.contactDataSource.length != 1) {
      this.contactTable.renderRows();
    }
  }

  update_Contact(data, tableRowId) {
    this.contactDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
        value.contact = data;
      }
    })
  }

  delete_Contact(tableRowId) {
    this.contactDataSource = this.contactDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.contactDataSource.length == 0) {
      this.contact = 'No';
      this.isContact = false;
    }
  }

  deleteAll_Contact() {
    if (this.contactDataSource.length != 0) {
      this.contactDataSource.splice(0, this.contactDataSource.length);
      this.isContact = false;
    }
  }

  /******** String Inverter Section ******/

  stringInverterDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let stringInverterComp = this.dialog.open(StringInverterComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    stringInverterComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.stringInverterDataSource.length != 0) {
          this.stringInverter = 'Yes';
        } else {
          this.stringInverter = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_StringInverter(res.data);
      if (res.event == 'Update')
        this.update_StringInverter(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_StringInverter(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_StringInverter();
    });
  }

  onStringInverterOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.stringInverterDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.stringInverterDataSource.length != 0)
        this.stringInverterDialog('DeleteAll', {});
    }
  }

  add_StringInverter(data) {
    this.isStringInverter = true;
    this.stringInverterDataSource.push({
      id: data.id,
      name: data.name,
      make: data.make,
      capacity: data.capacity,
      modelNo: data.modelNo,
      building: data.building,
      buildingType: data.buildingType,
      dataLoggerNo: data.dataLoggerNo,
      MPPT: data.MPPT,
      string: data.string,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.stringInverterDataSource.length != 1) {
      this.stringInverterTable.renderRows();
    }
  }

  update_StringInverter(data, tableRowId) {
    this.stringInverterDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
          value.id = data.id,
          value.name = data.name,
          value.make = data.make,
          value.capacity = data.capacity,
          value.modelNo = data.modelNo,
          value.building = data.building,
          value.buildingType = data.buildingType,
          value.dataLoggerNo = data.dataLoggerNo
      }
    })
  }

  delete_StringInverter(tableRowId) {
    // let newArr = [];
    this.stringInverterDataSource = this.stringInverterDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });
    // this.stringInverterDataSource.forEach((data, index) => {
    //   newArr.push({
    //   id: index + 1,
    //   name: data.name,
    //   make: data.make,
    //   capacity: data.capacity,
    //   modelNo: data.modelNo,
    //   building: data.building,
    //   buildingType: data.buildingType,
    //   dataLoggerNo: data.dataLoggerNo,
    //   MPPT: data.MPPT,
    //   string: data.string,
    //   edit: 'Edit',
    //   delete: 'Delete'
    // });
    // });
    // this.stringInverterDataSource = newArr;
    if (this.stringInverterDataSource.length == 0) {
      this.stringInverter = 'No';
      this.isStringInverter = false;
    }
  }

  deleteAll_StringInverter() {
    if (this.stringInverterDataSource.length != 0) {
      this.stringInverterDataSource.splice(0, this.stringInverterDataSource.length);
      this.isStringInverter = false;
    }
  }

  /******** Centralized Inverter Section ******/

  centralizedInverterDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let centralizedInverterComp = this.dialog.open(CentralizedInverterComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    centralizedInverterComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.centralizedInverterDataSource.length != 0) {
          this.centralizedInverter = 'Yes';
        } else {
          this.centralizedInverter = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_CentralizedInverter(res.data);
      if (res.event == 'Update')
        this.update_CentralizedInverter(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_CentralizedInverter(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_CentralizedInverter();
    });
  }

  centralizedInverterOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.centralizedInverterDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.centralizedInverterDataSource.length != 0)
        this.centralizedInverterDialog('DeleteAll', {});
    }
  }

  add_CentralizedInverter(data) {
    this.isCentralizedInverter = true;
    this.centralizedInverterDataSource.push({
      id: data.id,
      name: data.name,
      make: data.make,
      capacity: data.capacity,
      modelNo: data.modelNo,
      building: data.building,
      buildingType: data.buildingType,
      dataLoggerNo: data.dataLoggerNo,
      unit: data.unit,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.centralizedInverterDataSource.length != 1) {
      this.centralizedInverterTable.renderRows();
    }
  }

  update_CentralizedInverter(data, tableRowId) {
    this.centralizedInverterDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
          value.id = data.id
          value.name = data.name,
          value.make = data.make,
          value.capacity = data.capacity,
          value.modelNo = data.modelNo,
          value.building = data.building,
          value.buildingType = data.buildingType,
          value.dataLoggerNo = data.dataLoggerNo,
          value.unit = data.unit
      }
    });
  }

  delete_CentralizedInverter(tableRowId) {
    // let newArr = [];
    this.centralizedInverterDataSource = this.centralizedInverterDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });
    // this.centralizedInverterDataSource.forEach((data, index) => {
    //   newArr.push({
    //     id: index + 1,
    //     name: data.name,
    //     make: data.make,
    //     capacity: data.capacity,
    //     modelNo: data.modelNo,
    //     building: data.building,
    //     buildingType: data.buildingType,
    //     dataLoggerNo: data.dataLoggerNo,
    //     unit: data.unit,
    //     edit: 'Edit',
    //     delete: 'Delete'
    //   });
    // });
    // this.centralizedInverterDataSource = newArr;
    if (this.centralizedInverterDataSource.length == 0) {
      this.centralizedInverter = 'No';
      this.isCentralizedInverter = false;
    }
  }

  deleteAll_CentralizedInverter() {
    if (this.centralizedInverterDataSource.length != 0) {
      this.centralizedInverterDataSource.splice(0, this.centralizedInverterDataSource.length);
      this.isCentralizedInverter = false;
    }
  }

  /******** Meter Section ******/
  meterDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let meterComp = this.dialog.open(MeterComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    meterComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.meterDataSource.length != 0) {
          this.meter = 'Yes';
        } else {
          this.meter = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_Meter(res.data);
      if (res.event == 'Update')
        this.update_Meter(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_Meter(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_Meter();
    });
  }

  meterOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.meterDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.meterDataSource.length != 0)
        this.meterDialog('DeleteAll', {});
    }
  }

  add_Meter(data) {
    this.isMeter = true;
    this.meterDataSource.push({
      name: data.name,
      make: data.make,
      modelNo: data.modelNo,
      building: data.building,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.meterDataSource.length != 1) {
      this.meterTable.renderRows();
    }
  }

  update_Meter(data, tableRowId) {
    this.meterDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
        value.name = data.name,
          value.make = data.make,
          value.modelNo = data.modelNo,
          value.building = data.building
      }
    });
  }

  delete_Meter(tableRowId) {
    this.meterDataSource = this.meterDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.meterDataSource.length == 0) {
      this.meter = 'No';
      this.isMeter = false;
    }
  }

  deleteAll_Meter() {
    if (this.meterDataSource.length != 0) {
      this.meterDataSource.splice(0, this.meterDataSource.length);
      this.isMeter = false;
    }
  }

  /******** Panel Meter Section ******/

  panelMeterDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let panelMeterComp = this.dialog.open(PanelMeterComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    panelMeterComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.panelMeterDataSource.length != 0) {
          this.panelMeter = 'Yes';
        } else {
          this.panelMeter = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_PanelMeter(res.data);
      if (res.event == 'Update')
        this.update_PanelMeter(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_PanelMeter(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_PanelMeter();
    });
  }

  panelMeterOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.panelMeterDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.panelMeterDataSource.length != 0)
        this.panelMeterDialog('DeleteAll', {});
    }
  }

  add_PanelMeter(data) {
    this.isPanelMeter = true;
    this.panelMeterDataSource.push({
      name: data.name,
      make: data.make,
      modelNo: data.modelNo,
      solution: data.solution,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.panelMeterDataSource.length != 1) {
      this.panelMeterTable.renderRows();
    }
  }

  update_PanelMeter(data, tableRowId) {
    this.panelMeterDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
        value.name = data.name,
          value.make = data.make,
          value.modelNo = data.modelNo,
          value.solution = data.solution
      }
    });
  }

  delete_PanelMeter(tableRowId) {
    this.panelMeterDataSource = this.panelMeterDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.panelMeterDataSource.length == 0) {
      this.panelMeter = 'No';
      this.isPanelMeter = false;
    }
  }

  deleteAll_PanelMeter() {
    if (this.panelMeterDataSource.length != 0) {
      this.panelMeterDataSource.splice(0, this.panelMeterDataSource.length);
      this.isPanelMeter = false;
    }
  }


  /******** Diesel Generator Section ******/

  dieselGeneratorDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let dieselGeneratorComp = this.dialog.open(DieselGeneratorComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    dieselGeneratorComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.dieselGeneratorDataSource.length != 0) {
          this.dieselGenerator = 'Yes';
        } else {
          this.dieselGenerator = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_DieselGenerator(res.data);
      if (res.event == 'Update')
        this.update_DieselGenerator(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_DieselGenerator(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_DieselGenerator();
    });
  }

  dieselGeneratorOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.dieselGeneratorDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.dieselGeneratorDataSource.length != 0)
        this.dieselGeneratorDialog('DeleteAll', {});
    }
  }

  add_DieselGenerator(data) {
    this.isDieselGenerator = true;
    this.dieselGeneratorDataSource.push({
      name: data.name,
      capacity: data.capacity,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.dieselGeneratorDataSource.length != 1) {
      this.dieselGeneratorTable.renderRows();
    }
  }

  update_DieselGenerator(data, tableRowId) {
    this.dieselGeneratorDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
        value.name = data.name,
          value.capacity = data.capacity
      }
    });
  }

  delete_DieselGenerator(tableRowId) {
    this.dieselGeneratorDataSource = this.dieselGeneratorDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.dieselGeneratorDataSource.length == 0) {
      this.dieselGenerator = 'No';
      this.isDieselGenerator = false;
    }
  }

  deleteAll_DieselGenerator() {
    if (this.dieselGeneratorDataSource.length != 0) {
      this.dieselGeneratorDataSource.splice(0, this.dieselGeneratorDataSource.length);
      this.isDieselGenerator = false;
    }
  }


  /******** Zero Export Section ******/

  zeroExportDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let zeroExportComp = this.dialog.open(ZeroExportComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    zeroExportComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.zeroExportDataSource.length != 0) {
          this.zeroExport = 'Yes';
        } else {
          this.zeroExport = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_ZeroExport(res.data);
      if (res.event == 'Update')
        this.update_ZeroExport(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_ZeroExport(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_ZeroExport();
    });
  }

  zeroExportOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.zeroExportDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.zeroExportDataSource.length != 0)
        this.zeroExportDialog('DeleteAll', {});
    }
  }

  add_ZeroExport(data) {
    this.isZeroExport = true;
    this.zeroExportDataSource.push({
      name: data.name,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.zeroExportDataSource.length != 1) {
      this.zeroExportTable.renderRows();
    }
  }

  update_ZeroExport(data, tableRowId) {
    this.zeroExportDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
          value.name = data.name;
      }
    });
  }

  delete_ZeroExport(tableRowId) {
    this.zeroExportDataSource = this.zeroExportDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.zeroExportDataSource.length == 0) {
      this.zeroExport = 'No';
      this.isZeroExport = false;
    }
  }

  deleteAll_ZeroExport() {
    if (this.zeroExportDataSource.length != 0) {
      this.zeroExportDataSource.splice(0, this.zeroExportDataSource.length);
      this.isZeroExport = false;
    }
  }

    /******** Data Logger Section ******/

  dataLoggerDialog(action: string, obj: any) {
    obj.action = action;
    let dialog = this.customizeDialogBox(action);

    let dataLoggerComp = this.dialog.open(DataLoggerComponent, {
      data: obj,
      width: dialog.width,
      height: dialog.height,
      position: {
        top: dialog.top
      }
    });

    dataLoggerComp.afterClosed().subscribe(res => {
      if (res.event == 'Cancel') {
        if (this.dataLoggerDataSource.length != 0) {
          this.dataLogger = 'Yes';
        } else {
          this.dataLogger = 'No';
        }
      };
      if (res.event == 'Add')
        this.add_DataLogger(res.data);
      if (res.event == 'Update')
        this.update_DataLogger(res.data, res.index);
      if (res.event == 'Delete')
        this.delete_DataLogger(res.index);
      if (res.event == 'DeleteAll')
        this.deleteAll_DataLogger();
    });
  }

  dataLoggerOption(action: MatRadioChange) {
    if (action.value == 'Yes') {
      this.dataLoggerDialog('Add', {});
    }

    if (action.value == 'No') {
      if (this.dataLoggerDataSource.length != 0)
        this.dataLoggerDialog('DeleteAll', {});
    }
  }

  add_DataLogger(data) {
    this.isDataLogger = true;
    this.dataLoggerDataSource.push({
      name: data.name,
      make: data.make,
      modelNo: data.modelNo,
      serialNo: data.serialNo,
      building: data.building,
      deviceConnected: data.deviceConnected,
      edit: 'Edit',
      delete: 'Delete'
    });

    if (this.dataLoggerDataSource.length != 1) {
      this.dataLoggerTable.renderRows();
    }
  }

  update_DataLogger(data, tableRowId) {
    this.dataLoggerDataSource.filter((value, id) => {
      if (tableRowId == id + 1) {
          value.name = data.name;
          value.make = data.make;
          value.modelNo = data.modelNo;
          value.serialNo = data.serialNo;
          value.building = data.building;
          value.deviceConnected = data.deviceConnected;
      }
    });
  }

  delete_DataLogger(tableRowId) {
    this.dataLoggerDataSource = this.dataLoggerDataSource.filter((value, id) => {
      return tableRowId != id + 1;
    });

    if (this.dataLoggerDataSource.length == 0) {
      this.dataLogger = 'No';
      this.isDataLogger = false;
    }
  }

  deleteAll_DataLogger() {
    if (this.dataLoggerDataSource.length != 0) {
      this.dataLoggerDataSource.splice(0, this.dataLoggerDataSource.length);
      this.isDataLogger = false;
    }
  }
}