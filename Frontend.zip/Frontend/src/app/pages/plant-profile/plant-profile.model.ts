export interface Email {
    email: string;
    edit: string;
    delete: string;
}
  
export interface Contact {
    contact: any;
    edit: string;
    delete: string;
}
  
export interface stringInverter {
    id?: number;
    name: string;
    make: string;
    capacity: string;
    modelNo: any;
    building: any;
    buildingType: any;
    dataLoggerNo: any;
    MPPT: any;
    string: any;
    edit: string;
    delete: string;
}

export interface centralizedInverter {
    id?: number;
    name: string;
    make: string;
    capacity: string;
    modelNo: any;
    building: any;
    buildingType: any;
    dataLoggerNo: any;
    unit: any;
    edit: string;
    delete: string;
};

export interface Meter {
    // id: number;
    name: string;
    make: string;
    modelNo: any;
    building: any;
    edit: string;
    delete: string;
};

export interface panelMeter {
    // id: any;
    name: string;
    make: string;
    modelNo: any;
    solution: any;
    edit: string;
    delete: string;
}

export interface dieselGenerator {
    // id: any;
    name: any;
    capacity: any;
    edit: string;
    delete: string;
}

export interface zeroExport {
    // id: any;
    name: string;
    edit: string;
    delete: string;
}

export interface dataLogger {
    // id: any;
    name: any;
    make: any;
    modelNo: any;
    serialNo: any;
    building: any;
    deviceConnected: any;
    edit: string;
    delete: string;
}