import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { Subscription, Observable } from 'rxjs';
import { startWith, switchMap, map } from "rxjs/operators";

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { AuthService } from '../../auth/auth.service';
import { OutlineService } from '../outline.service'
import { MyProfileCards, MyProfileSites } from '../outline.model';

@Component({
  selector: "app-profile",
  templateUrl: "profile.component.html",
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, OnDestroy {

  public username : string;
  private Subscription:Subscription;
  private SubscriptionCards:Subscription;
  private SubscriptionSites:Subscription

  public myProfileCards : MyProfileCards = {
    clientName: '',
    totalSite: 0,
    totalCapacity: '0 kW',
    totalD_LOG: 0,
    totalInverter: 0,
    totalWeatherStation: 0,
    totalMeter: 0,
    totalPV_DGSync: 0,
    totalZeroExport: 0,
  }
  
  public myProfileSites: MyProfileSites[] = [
    {
      site: "",
      location: "",
      capacity: "",
      D_LOG: 0,
      inverter: 0,
      weatherStation : 0,
      meter : 0,
      PV_DGSync: 0,
      zeroExport:0,
      commissioningDate: "",
      portalExpiry: ""
    }
  ];

  displayedColumns: string[] = ['site', 'loaction', 'capacity', 'D_LOG', 'inverter','weatherStation','meter','PV_DGSync','zeroExport','commissioningDate','portalExpiry'];
  dataSource = new MatTableDataSource<MyProfileSites>(this.myProfileSites);

  slides: { image: string }[] = [{
      image: `../assets/img/carousel/default.jpg`
  }];
  activeSlideIndex = 0;
  public siteImages = [];

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(public authService:AuthService, public outlineService: OutlineService) { }

  ngOnInit() {
    this.username = this.authService.getUsername();

    this.Subscription = this.outlineService.getUserProfile(this.username)
    .pipe(
      map(map => {
        return {
          res:map.response.plantImages,
        };
      })
    )
    .subscribe(res => {
      this.siteImages = res['res'];
      this.slides = [];
      this.siteImages.forEach(element => {
       this.slides.push({
         image : element
       });
      });
    });

    this.SubscriptionCards = this.outlineService.getMyProfileCards(this.username)
    .pipe(
      map(map => {
        return {
          clientName: map.response.clientName,
          totalSite: +map.response.totalSite,
          totalCapacity: map.response.totalCapacity,
          totalD_LOG: +map.response.totalD_LOG,
          totalInverter: +map.response.totalInverter,
          totalWeatherStation: +map.response.totalWeatherStation,
          totalMeter: +map.response.totalMeter,
          totalPV_DGSync: +map.response.totalPV_DGSync,
          totalZeroExport: +map.response.totalZeroExport
        };
      })
    )
    .subscribe(res => {
      this.myProfileCards = res;
    });

    this.SubscriptionSites = this.outlineService.getMyProfileSites(this.username)
    .pipe(
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      this.myProfileSites = res['res'];
      this.dataSource = new MatTableDataSource<MyProfileSites>(this.myProfileSites);
    });
    this.dataSource.paginator = this.paginator;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy() {
    this.Subscription.unsubscribe();
    this.SubscriptionCards.unsubscribe();
    this.SubscriptionSites.unsubscribe();
  }
}
