export interface Response {
  status: boolean, 
  message: string, 
  response: any
}

export interface User {
  clientName: String,
  clientLogo: String,
  plants: Array <any>
}

export interface UserLocation {
  siteName: String,
  location: string,
  coordinates: Array <any>
}
    
export interface OverviewCards {
  totalCapacity: String,
  netTodayEnergy: String,
  D_LOGStatus: String,
  inverterStatus: string,
  weatherStationStatus: string,
  meterStatus: string,
  powerControlStatus: string
}

export interface OverviewSiteLevel {
  siteName?: string,
  siteId?: string,
  siteCapacity?: string,
  status?: string,
  class?: string,
  dailyEnergy?: string,
  dailyEnergyCurve?: number,
  specificEnergy?: number,
  specificEnergyCurve?: number,
  outputPower?: string,
  inputPower?: string,
  pr?: string,
  cuf?: string
}

export interface OverviewSiteCurve{
 X1 : Array<any>;
 Y1 : Array<any>;
 Y2 : Array<any>;
}

export interface MyProfileCards {
  clientName: string,
  totalSite: number,
  totalCapacity: String,
  totalD_LOG: number,
  totalInverter: number,
  totalWeatherStation: number,
  totalMeter: number,
  totalPV_DGSync: number,
  totalZeroExport: number,
}

export interface MyProfileSites {
  site: string;
  location: string;
  capacity: string;
  D_LOG:number;
  inverter:number;
  weatherStation:number;
  meter:number;
  PV_DGSync:number;
  zeroExport:number;
  commissioningDate: string;
  portalExpiry: string;
}