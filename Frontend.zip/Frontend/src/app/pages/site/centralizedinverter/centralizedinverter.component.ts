import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, Observable, interval } from 'rxjs';

import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment} from 'moment';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { CentralizedInverterCard, CentralizedInverterCurve, CentralizedInverterParameter } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-centralizedinverter",
  templateUrl: "centralizedinverter.component.html",
  styleUrls: ['./centralizedinverter.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class CentralizedInverterComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;
  private subscriptionInverterCard: Subscription;
  private subscriptionInverterCurve: Subscription;
  private subscriptionInverterParameter: Subscription;
  timer$ : Observable<number> = interval(60000);
  
  public username: string;
  public siteId: string;
  public devices = [];
  public inverterCard : CentralizedInverterCard ={};
  public inverterParameter : CentralizedInverterParameter ={};

  public selectedInverter : string;
  public selectedPerformanceOverview = '1';
  public selectedUnitInput= '1';
  public datePicker = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public InputInverterCurveData : CentralizedInverterCurve ={
    time :[],
    dailyYield: [],
    totalYield :[],
    Unit1:[],
    Unit2:[]
  }

  highcharts = Highcharts;
  
  public performanceOverviewCurveOption : any = {   
      chart: {
         type: "spline",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.InputInverterCurveData.time
      },
      yAxis: [{ // Primary yAxis
        title: {
            text: 'Daily Yield (kWh)'
          },
        }, { // Secondary yAxis
        title: {
            text: 'Total Yield (kWh)',
        },
        opposite: true
      }],
      series: [{
        name: 'Daily Yield',
        data: this.InputInverterCurveData.dailyYield,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' kWh'
        } 
      },{
        name: 'Total Yield',
        yAxis:1,
        color: '#F4B400',
        data: this.InputInverterCurveData.totalYield,
        tooltip: {
        valueSuffix: ' kWh'
        }
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: +5,
            y: -12
        }
      },
      plotOptions:{
        spline: {
          marker: {
              radius: 3,
              states: { hover: { radius: 6 } }
          },
        }
      },
  };

  public UnitInputCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    // colors:["#7cb5ec", "#434348", "#90ed7d", "#f7a35c", "#8085e9", "#f15c80", "#e4d354", "#2b908f", "#f45b5b", "#91e8e1"],
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.InputInverterCurveData.time
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Current (A)'
        },
      }],
    series: [{
      name: 'Unit1',
      data: this.InputInverterCurveData.Unit1,
      tooltip: {
      valueSuffix: ' A'
      }
    },
    {
      name: 'Unit2',
      data: this.InputInverterCurveData.Unit2,
      tooltip: {
        valueSuffix: ' A'
        }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 3,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };

  public updateFlag : boolean = false;
  public oneToOneFlag : boolean = true;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}

  async ngOnInit() : Promise<void> {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          devices:map.response.centralizedInverter
        };
      })
    )
    .subscribe(res => {
      res.devices.forEach(element => {
        this.devices.push({name:element.building+' '+element.name, id:element.id})
      });
      console.log( this.devices)
      this.selectedInverter = this.devices[0].id.toString();
      this.inverterCards();
      this.inverterCurve();
      this.inverterParameters()
   });
  }

  inverterCards(){
    this.subscriptionInverterCard = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getCentralizedInverterCard(this.username, this.siteId, this.selectedInverter)),
      map(map => {
        return {
          timestamp: map.response.timestamp,
          status: map.response.status,
          todayYield: map.response.todayYield,
          totalYield: map.response.totalYield,
          outputPower: map.response.outputPower,
          inputPower: map.response.inputPower,
          peakOutputPower: map.response.peakOutputPower,
          peakOutputPowerTimestamp: map.response.peakOutputPowerTimestamp,
          specificYield: map.response.specificYield,
          specificPower: map.response.specificPower,
          temperature: map.response.temperature,
          efficiency: map.response.efficiency,
          capacity: map.response.capacity
        };
      })
    )
    .subscribe(res => {
      this.inverterCard = res;
  });
  }

  inverterCurve(){
    this.subscriptionInverterCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getCentralizedInverterCurve(this.username, this.siteId, this.selectedInverter,this.datePicker.value)),
      map(map => {
        return {
          time : map.response.time,
          dailyYield : map.response.dailyYield,
          totalYield : map.response.totalYield,
          outputCurrent : map.response.outputCurrent,
          inputCurrent : map.response.inputCurrent,
          outputPower : map.response.outputPower,
          inputPower : map.response.inputPower,
          temperature : map.response.temperature,
          efficiency : map.response.efficiency,
          Unit1: map.response.currentUnit1,
          Unit2: map.response.currentUnit2,
          Unit3: map.response.currentUnit3,
          Unit4: map.response.currentUnit4,
          Unit5: map.response.currentUnit5,
          Unit6: map.response.currentUnit6,
          Unit7: map.response.currentUnit7,
          Unit8: map.response.currentUnit8,
          Unit9: map.response.currentUnit9,
          Unit10: map.response.currentUnit10,
          Unit11: map.response.currentUnit11,
          Unit12: map.response.currentUnit12,
          Unit13: map.response.currentUnit13,
          Unit14: map.response.currentUnit14,
          Unit15: map.response.currentUnit15,
          Input1: map.response.currentInput1,
          Input2: map.response.currentInput2,
          Input3: map.response.currentInput3,
          Input4: map.response.currentInput4,
          Input5: map.response.currentInput5,
          Input6: map.response.currentInput6,
          Input7: map.response.currentInput7,
          Input8: map.response.currentInput8,
          Input9: map.response.currentInput9,
          Input10: map.response.currentInput10,
          Input11: map.response.currentInput11,
          Input12: map.response.currentInput12,
          Input13: map.response.currentInput13,
          Input14: map.response.currentInput14,
          Input15: map.response.currentInput15,
          Input16: map.response.currentInput16,
          Input17: map.response.currentInput17,
          Input18: map.response.currentInput18,
          Input19: map.response.currentInput19,
          Input20: map.response.currentInput20,
          Input21: map.response.currentInput21,
          Input22: map.response.currentInput22,
          Input23: map.response.currentInput23,
          Input24: map.response.currentInput24,
          Input25: map.response.currentInput25,
          Input26: map.response.currentInput26,
          Input27: map.response.currentInput27,
          Input28: map.response.currentInput28,
          Input29: map.response.currentInput29,
          Input30: map.response.currentInput30
        };
      })
    )
    .subscribe(res => {
      this.InputInverterCurveData = res;
    
      this.performanceOverviewCurveOption.xAxis={
        categories:this.InputInverterCurveData.time
      };

      this.performanceOverviewCurveOption.series=[];

      if(this.selectedPerformanceOverview == '1')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Daily Yield (kWh)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Total Yield (kWh)',
          },
          opposite: true
        }];

        this.performanceOverviewCurveOption.series=[{
          name: 'Daily Yield',
          data: this.InputInverterCurveData.dailyYield,
          color: '#4285F4',
          tooltip: {
          valueSuffix: ' kWh'
          } 
        },{
          name: 'Total Yield',
          yAxis:1,
          data: this.InputInverterCurveData.totalYield,
          color: '#F4B400',
          tooltip: {
          valueSuffix: ' kWh'
          }
        }];
      }
      else if(this.selectedPerformanceOverview == '2')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Output Power & Input Power (kW)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Output Current & Input Current (A)',
          },
          opposite: true
        }];
       
        this.performanceOverviewCurveOption.series=[{
          name: 'Output Power',
          data: this.InputInverterCurveData.outputPower,
          yAxis:0,
          color: '#EE2558',
          tooltip: {
          valueSuffix: ' kW',
          }
        }, {
          name: 'Input Power',
          data: this.InputInverterCurveData.inputPower,
          yAxis:0,
          color: '#1BB79A',
          tooltip: {
          valueSuffix: ' kW',
          }
        }, {
          name: 'Output Current',
          data: this.InputInverterCurveData.outputCurrent,
          yAxis:1,
          color: '#36A7E6',
          tooltip: {
          valueSuffix: ' A',
          }
        }, {
          name: 'Input Current',
          data: this.InputInverterCurveData.inputCurrent,
          yAxis:1,
          color: '#F4B400',
          tooltip: {
          valueSuffix: ' A',
          }
        }];
      }
      else if(this.selectedPerformanceOverview =='3')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Efficiency (%)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Temperature (°C)',
          },
          opposite: true
        }];

        this.performanceOverviewCurveOption.series=[{
          name: 'Efficiency',
          data: this.InputInverterCurveData.efficiency,
          color: '#86C541',
          tooltip: {
          valueSuffix: ' %',
          }
        }, {
          name: 'Temperature',
          data: this.InputInverterCurveData.temperature,
          yAxis:1,
          color: '#F58731',
          tooltip: {
          valueSuffix: ' °C',
          }
        }];
      }

      this.UnitInputCurveOption.xAxis={
        categories:this.InputInverterCurveData.time
      };
      
      this.UnitInputCurveOption.series=[];

      if(this.selectedUnitInput == '1')
      {

        this.UnitInputCurveOption.yAxis=[{ 
          title: {
              text: 'Unit Current (A)'
            },
          }];

          if(this.InputInverterCurveData.Unit1)
            this.UnitInputCurveOption.series[0]={
              name: 'Unit 1',
              data: this.InputInverterCurveData.Unit1,
              // color:'#dc4c8f',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit2)
            this.UnitInputCurveOption.series[1]={
              name: 'Unit 2',
              data: this.InputInverterCurveData.Unit2,
              // color:'#47c3cd',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit3)
            this.UnitInputCurveOption.series[2]={
              name: 'Unit 3',
              data: this.InputInverterCurveData.Unit3,
              // color:'#6F60B8',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit4)
            this.UnitInputCurveOption.series[3]={
              name: 'Unit 4',
              data: this.InputInverterCurveData.Unit4,
              //color:'#F27C47',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit5)
            this.UnitInputCurveOption.series[4]={
              name: 'Unit 5',
              data: this.InputInverterCurveData.Unit5,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit6)
            this.UnitInputCurveOption.series[5]={
              name: 'Unit 6',
              data: this.InputInverterCurveData.Unit6,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit7)
            this.UnitInputCurveOption.series[6]={
              name: 'Unit 7',
              data: this.InputInverterCurveData.Unit7,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit8)
            this.UnitInputCurveOption.series[7]={
              name: 'Unit 8',
              data: this.InputInverterCurveData.Unit8,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit9)
            this.UnitInputCurveOption.series[8]={
              name: 'Unit 9',
              data: this.InputInverterCurveData.Unit9,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit10)
            this.UnitInputCurveOption.series[9]={
              name: 'Unit 10',
              data: this.InputInverterCurveData.Unit10,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit11)
            this.UnitInputCurveOption.series[10]={
              name: 'Unit 11',
              data: this.InputInverterCurveData.Unit11,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit12)
            this.UnitInputCurveOption.series[11]={
              name: 'Unit 12',
              data: this.InputInverterCurveData.Unit12,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit13)
            this.UnitInputCurveOption.series[12]={
              name: 'Unit 13',
              data: this.InputInverterCurveData.Unit13,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit14)
            this.UnitInputCurveOption.series[13]={
              name: 'Unit 14',
              data: this.InputInverterCurveData.Unit14,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.InputInverterCurveData.Unit15)
            this.UnitInputCurveOption.series[14]={
              name: 'Unit 15',
              data: this.InputInverterCurveData.Unit15,
              tooltip: {
              valueSuffix: ' A'
              }
            };

      }
      else if(this.selectedUnitInput == '2')
      {
        this.UnitInputCurveOption.yAxis=[{ 
          title: {
              text: 'Input Current (A)'
            },
          }];

        if(this.InputInverterCurveData.Input1)
          this.UnitInputCurveOption.series[0]={
            name: 'Input 1',
            data: this.InputInverterCurveData.Input1,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input2)
          this.UnitInputCurveOption.series[1]={
            name: 'Input 2',
            data: this.InputInverterCurveData.Input2,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input3)
          this.UnitInputCurveOption.series[2]={
            name: 'Input 3',
            data: this.InputInverterCurveData.Input3,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input4)
          this.UnitInputCurveOption.series[3]={
            name: 'Input 4',
            data: this.InputInverterCurveData.Input4,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input5)
          this.UnitInputCurveOption.series[4]={
            name: 'Input 5',
            data: this.InputInverterCurveData.Input5,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input6)
          this.UnitInputCurveOption.series[5]={
            name: 'Input 6',
            data: this.InputInverterCurveData.Input6,
            tooltip: {
            valueSuffix: ' A'
            }
          };
          if(this.InputInverterCurveData.Input7)
          this.UnitInputCurveOption.series[6]={
            name: 'Input 7',
            data: this.InputInverterCurveData.Input7,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input8)
          this.UnitInputCurveOption.series[7]={
            name: 'Input 8',
            data: this.InputInverterCurveData.Input8,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input9)
          this.UnitInputCurveOption.series[8]={
            name: 'Input 9',
            data: this.InputInverterCurveData.Input9,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input10)
          this.UnitInputCurveOption.series[9]={
            name: 'Input 10',
            data: this.InputInverterCurveData.Input10,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.InputInverterCurveData.Input11)
          this.UnitInputCurveOption.series[10]={
            name: 'Input 11',
            data: this.InputInverterCurveData.Input11,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input12)
          this.UnitInputCurveOption.series[11]={
            name: 'Input 12',
            data: this.InputInverterCurveData.Input12,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input13)
          this.UnitInputCurveOption.series[12]={
            name: 'Input 13',
            data: this.InputInverterCurveData.Input13,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input14)
          this.UnitInputCurveOption.series[13]={
            name: 'Input 14',
            data: this.InputInverterCurveData.Input14,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input15)
          this.UnitInputCurveOption.series[14]={
            name: 'Input 15',
            data: this.InputInverterCurveData.Input15,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input16)
          this.UnitInputCurveOption.series[15]={
            name: 'Input 16',
            data: this.InputInverterCurveData.Input16,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input17)
          this.UnitInputCurveOption.series[16]={
            name: 'Input 17',
            data: this.InputInverterCurveData.Input17,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input18)
          this.UnitInputCurveOption.series[17]={
            name: 'Input 18',
            data: this.InputInverterCurveData.Input18,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input19)
          this.UnitInputCurveOption.series[18]={
            name: 'Input 19',
            data: this.InputInverterCurveData.Input19,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input20)
          this.UnitInputCurveOption.series[19]={
            name: 'Input 20',
            data: this.InputInverterCurveData.Input20,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input21)
          this.UnitInputCurveOption.series[20]={
            name: 'Input 21',
            data: this.InputInverterCurveData.Input21,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input22)
          this.UnitInputCurveOption.series[21]={
            name: 'Input 22',
            data: this.InputInverterCurveData.Input22,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input23)
          this.UnitInputCurveOption.series[22]={
            name: 'Input 23',
            data: this.InputInverterCurveData.Input23,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input24)
          this.UnitInputCurveOption.series[23]={
            name: 'Input 24',
            data: this.InputInverterCurveData.Input24,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input25)
          this.UnitInputCurveOption.series[24]={
            name: 'Input 25',
            data: this.InputInverterCurveData.Input25,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input26)
          this.UnitInputCurveOption.series[25]={
            name: 'Input 26',
            data: this.InputInverterCurveData.Input26,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input27)
          this.UnitInputCurveOption.series[26]={
            name: 'Input 27',
            data: this.InputInverterCurveData.Input27,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input28)
          this.UnitInputCurveOption.series[27]={
            name: 'Input 28',
            data: this.InputInverterCurveData.Input28,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input29)
          this.UnitInputCurveOption.series[28]={
            name: 'Input 29',
            data: this.InputInverterCurveData.Input29,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.InputInverterCurveData.Input30)
          this.UnitInputCurveOption.series[29]={
            name: 'Input 30',
            data: this.InputInverterCurveData.Input30,
            tooltip: {
            valueSuffix: ' A'
            }
          };
      }

      this.updateFlag=true;
      this.oneToOneFlag =true;
    });
  }
  
  inverterParameters(){
    this.subscriptionInverterParameter = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getCentralizedInverterParameter(this.username, this.siteId, this.selectedInverter)),
      map(map => {
        return {
          inputVoltage: map.response.inputVoltage,
          inputCurrent: map.response.inputCurrent,
          inputPower: map.response.inputPower,
          voltagePhaseR: map.response.voltagePhaseR,
          voltagePhaseY: map.response.voltagePhaseY,
          voltagePhaseB: map.response.voltagePhaseB,
          currentPhaseR: map.response.currentPhaseR,
          currentPhaseY: map.response.currentPhaseY,
          currentPhaseB: map.response.currentPhaseB,
          powerPhaseR: map.response.powerPhaseR,
          powerPhaseY: map.response.powerPhaseY,
          powerPhaseB: map.response.powerPhaseB,
          activePower: map.response.activePower,
          reactivePower: map.response.reactivePower,
          apparentPower: map.response.apparentPower
        };
      })
    )
    .subscribe(res => {
     this.inverterParameter = res;
     console.log(res)
  });
  }
  
  changeInverter() {
    this.subscriptionInverterCard.unsubscribe();
    this.subscriptionInverterCurve.unsubscribe();
    this.subscriptionInverterParameter.unsubscribe();
    this.inverterCards();
    this.inverterCurve();
    this.inverterParameters();
  }

  changeDate(event: MatDatepickerInputEvent<Date>){
    this.datePicker.setValue(event.value)
    this.subscriptionInverterCurve.unsubscribe();
    this.inverterCurve();
  }

  changeSelection(){
    this.subscriptionInverterCurve.unsubscribe();
    this.inverterCurve();   
  }
  
  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
    this.subscriptionInverterCard.unsubscribe();
    this.subscriptionInverterCurve.unsubscribe();
    this.subscriptionInverterParameter.unsubscribe();
   }
}
