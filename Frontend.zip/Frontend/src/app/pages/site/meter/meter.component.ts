import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, Observable, interval } from 'rxjs';

import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment} from 'moment';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { MeterCard, MeterYieldCurve, MeterAnalysisCurve, MeterParameter } from '../site.model';
 
const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-meter",
  templateUrl: "meter.component.html",
  styleUrls: ['./meter.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class MeterComponent implements OnInit, OnDestroy {
 
  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;
  private subscriptionMeterCard: Subscription;
  private subscriptionMeterCurve1: Subscription;
  private subscriptionMeterCurve2: Subscription;
  private subscriptionMeterParameter: Subscription;

  timer$ : Observable<number> = interval(60000);
  
  public username: string;
  public siteId: string;
  public selectedMeter : string;
  public devices = [];

  public meterCard : MeterCard ={};

  public datePicker = new FormControl(moment());
  public datePicker1 = new FormControl(moment());
  public datePicker2 = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public selectedYieldAnalysis = '1';
  public selectedParameter = '1';

  public meterYieldCurveData : MeterYieldCurve ={
    timestamp :[]
  }

  highcharts = Highcharts;
  
  public meterYieldCurveOption : any = {   
      chart: {
         type: "spline",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.meterYieldCurveData.timestamp
      },
      yAxis: [],
      series: [],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: +5,
            y: -12
        }
      },
      plotOptions:{
        spline: {
          marker: {
              radius: 2,
              states: { hover: { radius: 6 } }
          },
        }
      },
  };

  public meterYieldUpdateFlag : boolean = false;
  public meterYieldOneToOneFlag : boolean = true;

  public meterParameter : MeterParameter ={};

  public meterAnalysisCurveData : MeterAnalysisCurve ={
    timestamp :[]
  }

  public meterAnalysisCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.meterAnalysisCurveData.timestamp
    },
    yAxis: [],
    series: [],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 2,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };

  public meterAnalysisUpdateFlag : boolean = true;
  public meterAnalysisOneToOneFlag : boolean = true;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}

  async ngOnInit() : Promise<void> {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          devices:map.response.meter
        };
      })
    )
    .subscribe(res => {
      res.devices.forEach(element => {
        this.devices.push({name:element.building+' '+element.name, id:element.id})
      });
      this.selectedMeter = this.devices[0].id.toString();
      this.meterCards();
      this.meterYieldCurve();
      this.meterAnalysisCurve();
      this.meterParameters();
   });  
  }

  meterCards()
  {
    this.subscriptionMeterCard = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getMeterCard(this.username, this.siteId, this.selectedMeter)),
      map(map => {
        return {
          timestamp: map.response.timestamp,
          status: map.response.status,
          frequency: map.response.frequency,
          powerFactor: map.response.powerFactor,
          activeYieldExport: map.response.activeEnergyExport,
          activeYieldImport: map.response.activeEnergyImport,
        };
      })
    )
    .subscribe(res => {
      this.meterCard = res;
    });
  }

  meterYieldCurve(){
    this.subscriptionMeterCurve1 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getMeterCurve(this.username, this.siteId, this.selectedMeter,this.datePicker1.value)),
      map(map => {
        return {
          timestamp : map.response.time,
          activeYieldExport:map.response.activeEnergyExport,
          activeYieldImport: map.response.activeEnergyImport,
          todayActiveYieldExport: map.response.todayActiveEnergyExport,
          todayActiveYieldImport: map.response.todayActiveEnergyImport
        };
      })
    )
    .subscribe(res => {
      this.meterYieldCurveData = res;

      this.meterYieldCurveOption.xAxis=[];
      this.meterYieldCurveOption.yAxis=[];
      this.meterYieldCurveOption.series=[];

      this.meterYieldCurveOption.xAxis={
        categories:this.meterYieldCurveData.timestamp
      };
      
      if(this.selectedYieldAnalysis == '1')
      {
        this.meterYieldCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Total Active Yield Export (kWh)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Total Active Yield Import (kWh)',
          },
          opposite: true
        }];

        this.meterYieldCurveOption.series=[{
          name: 'Total Active Yield Export',
          data: this.meterYieldCurveData.activeYieldExport,
          color: '#4285F4',
          tooltip: {
          valueSuffix: ' kWh'
          } 
        },{
          name: 'Total Active Yield Import',
          yAxis:1,
          data: this.meterYieldCurveData.activeYieldImport,
          color: '#F4B400',
          tooltip: {
          valueSuffix: ' kWh'
          }
        }];
      }
      else if(this.selectedYieldAnalysis == '2')
      {

        this.meterYieldCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Today Active Yield Export (kWh)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Today Active Yield Import (kWh)',
          },
          opposite: true
        }];
       
        this.meterYieldCurveOption.series=[{
          name: 'Today Active Yield Export',
          data: this.meterYieldCurveData.todayActiveYieldExport,
          yAxis:0,
          color: '#EE2558',
          tooltip: {
          valueSuffix: ' kWh',
          }
        }, {
          name: 'Today Active Yield Import',
          data: this.meterYieldCurveData.todayActiveYieldImport,
          yAxis:1,
          color: '#1BB79A',
          tooltip: {
          valueSuffix: ' kWh',
          }
        }];
      }
      this.meterYieldUpdateFlag=true;
      this.meterYieldOneToOneFlag =true;
    });
  }

  meterAnalysisCurve(){
    this.subscriptionMeterCurve2 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getMeterCurve(this.username, this.siteId, this.selectedMeter,this.datePicker2.value)),
      map(map => {
        return {
          timestamp : map.response.time,
          powerFactorPhaseR: map.response.powerFactorPhaseR,
          powerFactorPhaseY: map.response.powerFactorPhaseY,
          powerFactorPhaseB: map.response.powerFactorPhaseB,
          voltagePhaseR: map.response.voltagePhaseR,
          voltagePhaseY: map.response.voltagePhaseY,
          voltagePhaseB: map.response.voltagePhaseB, 
          currentPhaseR: map.response.currentPhaseR,
          currentPhaseY: map.response.currentPhaseY,
          currentPhaseB: map.response.currentPhaseB,
          activePowerPhaseR: map.response.activePowerPhaseR,
          activePowerPhaseY: map.response.activePowerPhaseY,
          activePowerPhaseB: map.response.activePowerPhaseB,
          frequency: map.response.frequency
        };
      })
    )
    .subscribe(res => {
      this.meterAnalysisCurveData = res;
          
      this.meterAnalysisCurveOption.xAxis=[];
      this.meterAnalysisCurveOption.yAxis=[];
      this.meterAnalysisCurveOption.series=[];

      this.meterAnalysisCurveOption.xAxis={
        categories:this.meterAnalysisCurveData.timestamp
      };
      
      if(this.selectedParameter == '1')
      {
        this.meterAnalysisCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Voltage (V)'
            },
          }];

          this.meterAnalysisCurveOption.series.push(
            {
              name: 'Voltage Phase R',
              data: this.meterAnalysisCurveData.voltagePhaseR,
              tooltip: {
              valueSuffix: ' V'
              }
            },
            {
              name: 'Voltage Phase Y',
              data: this.meterAnalysisCurveData.voltagePhaseY,
              tooltip: {
              valueSuffix: ' V'
              }
            },
            {
              name: 'Voltage Phase B',
              data: this.meterAnalysisCurveData.voltagePhaseB,
              color:"#7169E3",
              tooltip: {
              valueSuffix: ' V'
              },
            });
      }
      else if(this.selectedParameter == '2')
      {
        this.meterAnalysisCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Current (A)'
            },
          }];
       
          this.meterAnalysisCurveOption.series.push(
            {
              name: 'Current Phase R',
              data: this.meterAnalysisCurveData.currentPhaseR,
              color:"#F1DF00",
              tooltip: {
              valueSuffix: ' A'
              }
            },
            {
              name: 'Current Phase Y',
              data: this.meterAnalysisCurveData.currentPhaseY,
              color:"#2DCE89",
              tooltip: {
              valueSuffix: ' A'
              }
            },
            {
              name: 'Current Phase B',
              data: this.meterAnalysisCurveData.currentPhaseB,
              color:"#F9AA42",
              tooltip: {
              valueSuffix: ' A'
              },
            }
            );
      }
      else if(this.selectedParameter == '3')
      {
        this.meterAnalysisCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Power (kW)'
            },
          }];
       
          this.meterAnalysisCurveOption.series.push(
            {
              name: 'Power Phase R',
              data: this.meterAnalysisCurveData.activePowerPhaseR,
              color:"#F1DF00",
              tooltip: {
              valueSuffix: ' kW'
              }
            },
            {
              name: 'Power Phase Y',
              data: this.meterAnalysisCurveData.activePowerPhaseY,
              color:"#2DCE89",
              tooltip: {
              valueSuffix: ' kW'
              }
            },
            {
              name: 'Power Phase B',
              data: this.meterAnalysisCurveData.activePowerPhaseB,
              color:"#F9AA42",
              tooltip: {
              valueSuffix: ' kW'
              },
            }
            );
      }
      else if(this.selectedParameter == '4')
      {
        this.meterAnalysisCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Power Factor'
            },
          }];
       
          this.meterAnalysisCurveOption.series.push(
            {
              name: 'Power Factor Phase R',
              data: this.meterAnalysisCurveData.powerFactorPhaseR,
              color:"#F1DF00",
              tooltip: {
              valueSuffix: ''
              }
            },
            {
              name: 'Power Factor Phase Y',
              data: this.meterAnalysisCurveData.powerFactorPhaseY,
              color:"#2DCE89",
              tooltip: {
              valueSuffix: ''
              }
            },
            {
              name: 'Power Factor Phase B',
              data: this.meterAnalysisCurveData.powerFactorPhaseB,
              color:"#F9AA42",
              tooltip: {
              valueSuffix: ''
              },
            }
            );
      }
      else if(this.selectedParameter == '5')
      {
        this.meterAnalysisCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Frequency (Hz)'
            },
          }];
       
          this.meterAnalysisCurveOption.series.push(
            {
              name: 'Frequency',
              data: this.meterAnalysisCurveData.frequency,
              color:"#F1DF00",
              tooltip: {
              valueSuffix: ' Hz'
              }
            });
      }
      
      this.meterAnalysisUpdateFlag=true;
      this.meterAnalysisOneToOneFlag =true;
    });
  }

  meterParameters(){
    this.subscriptionMeterParameter = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getMeterParameter(this.username, this.siteId, this.selectedMeter)),
      map(map => {
        return {
          powerFactorPhaseR: map.response.powerFactorPhaseR,
          powerFactorPhaseY: map.response.powerFactorPhaseY,
          powerFactorPhaseB: map.response.powerFactorPhaseB,
          voltagePhaseR: map.response.voltagePhaseR,
          voltagePhaseY: map.response.voltagePhaseY,
          voltagePhaseB: map.response.voltagePhaseB,
          currentPhaseR: map.response.currentPhaseR,
          currentPhaseY: map.response.currentPhaseY,
          currentPhaseB: map.response.currentPhaseB,
          activePowerPhaseR: map.response.activePowerPhaseR,
          activePowerPhaseY: map.response.activePowerPhaseY,
          activePowerPhaseB: map.response.activePowerPhaseB,
          activePower: map.response.activePower,
          reactivePower: map.response.reactivePower,
          apparentPower: map.response.apparentPower
        };
      })
    )
    .subscribe(res => {
     this.meterParameter = res;
    });
  }

  changeMeter()
  {
    this.subscriptionMeterCard.unsubscribe();
    this.subscriptionMeterCurve1.unsubscribe();
    this.subscriptionMeterCurve2.unsubscribe();
    this.subscriptionMeterParameter.unsubscribe();
    this.meterCards();
    this.meterYieldCurve();
    this.meterAnalysisCurve();
    this.meterParameters();
  }

  changeYieldAnalysis()
  {
    this.subscriptionMeterCurve1.unsubscribe();
    this.meterYieldCurve();
  }

  changeParameterSelection()
  {
    this.subscriptionMeterCurve2.unsubscribe();
    this.meterAnalysisCurve();
  }

  changeDatePicker1(event: MatDatepickerInputEvent<Date>){
    this.datePicker1.setValue(event.value)
    this.subscriptionMeterCurve1.unsubscribe();
    this.meterYieldCurve();
  }

  changeDatePicker2(event: MatDatepickerInputEvent<Date>){
    this.datePicker2.setValue(event.value)
    this.subscriptionMeterCurve2.unsubscribe();
    this.meterAnalysisCurve();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
    this.subscriptionMeterCard.unsubscribe();
    this.subscriptionMeterCurve1.unsubscribe();
    this.subscriptionMeterCurve2.unsubscribe();
    this.subscriptionMeterParameter.unsubscribe();
   }
}
