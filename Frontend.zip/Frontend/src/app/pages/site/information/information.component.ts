import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

import { takeUntil, map } from 'rxjs/operators';
import { Subject, Subscription } from 'rxjs';

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { 
  InformationCard,
  D_LOGProfile,
  StringInverterProfile,
  CentralizedInverterProfile,
  WeatherStationProfile,
  MeterProfile,
  DieselGeneratorProfile
 } from '../site.model';

@Component({
  selector: "app-information",
  templateUrl: "information.component.html",
  styleUrls: ['./information.component.scss']
})

export class InformationComponent implements OnInit, OnDestroy {

  public siteId: string;
  public username: string;
  private Subscription:Subscription;
  private SubscriptionProfile:Subscription;
  private destroy = new Subject<void>();

  public informationCard :InformationCard = { };

  public D_LOGIsActive = true ;
  public stringInverterIsActive = true ;
  public centralizedInverterIsActive = false ;
  public weatherStationIsActive = false ;
  public meterIsActive = false ;
  public dieselGeneratorIsActive = false ;
  public D_LOGProfileData : D_LOGProfile[] = [];
  public stringInverterProfileData: StringInverterProfile[] = [];
  public centralizedInverterProfileData: CentralizedInverterProfile[] = [];
  public weatherStationProfileData: WeatherStationProfile[] = [];
  public meterProfileData: MeterProfile[] = [];
  public dieselGeneratorProfileData: DieselGeneratorProfile[] = [];

  d_logColumns: string[] = ['name', 'modelNo', 'serialNo', 'building', 'deviceConnected'];
  stringInverterColumns: string[] = ['name', 'capacity', 'make', 'modelNo', 'serialNo', 'building', 'string'];
  centralizedInverterColumns: string[] = ['name', 'capacity', 'make', 'modelNo', 'serialNo', 'building', 'unit'];
  weatherStationColumns: string[] = ['name', 'make', 'modelNo', 'serialNo', 'building', 'sensors'];
  meterColumns: string[] = ['name', 'make', 'modelNo', 'serialNo', 'building'];
  dieselGeneratorColumns: string[] = ['name', 'capacity', 'make', 'modelNo', 'building'];
  d_logSource = new MatTableDataSource<D_LOGProfile>(this.D_LOGProfileData);
  stringInverterSource = new MatTableDataSource<StringInverterProfile>(this.stringInverterProfileData);
  centralizedInverterSource = new MatTableDataSource<CentralizedInverterProfile>(this.centralizedInverterProfileData);
  weatherStationSource = new MatTableDataSource<WeatherStationProfile>(this.weatherStationProfileData);
  meterSource = new MatTableDataSource<MeterProfile>(this.meterProfileData);
  dieselGeneratorSource = new MatTableDataSource<DieselGeneratorProfile>(this.dieselGeneratorProfileData);

  @ViewChild('paginator1') paginator1: MatPaginator;
  @ViewChild('paginator2') paginator2: MatPaginator;
  @ViewChild('paginator3') paginator3: MatPaginator;
  @ViewChild('paginator4') paginator4: MatPaginator;
  @ViewChild('paginator5') paginator5: MatPaginator;
  @ViewChild('paginator5') paginator6: MatPaginator;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService:AuthService) {}

  ngAfterViewInit() {
    this.d_logSource.paginator = this.paginator1;
    this.stringInverterSource.paginator = this.paginator2;
    this.centralizedInverterSource.paginator = this.paginator3;
    this.weatherStationSource.paginator = this.paginator4;
    this.meterSource.paginator = this.paginator5;
    this.dieselGeneratorSource.paginator = this.paginator6;
  }

  async ngOnInit() : Promise<void>{
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    
    this.username = this.authService.getUsername();
    this.siteId = await this.siteService.getSiteId();

    this.Subscription = this.siteService.getInformationCard(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          siteName : map.response.siteName,
          capacity : map.response.capacity,
          location : map.response.location,
          coordinates : map.response.coordinates,
          commissioningDate : map.response.commissioningDate,
          portalLicenseDate : map.response.portalLicenseDate,
          owner : map.response.owner,
          unitPrice : map.response.unitPrice,
          D_LOG : map.response.D_LOG,
          inverter : map.response.inverter,
          weatherStation : map.response.weatherStation,
          meter : map.response.meter,
          PV_DGSync : map.response.PV_DGSync,
          zeroExport : map.response.zeroExport,
          PVModuleQuantity : map.response.PVModuleQuantity,
          PVModuleWattage : map.response.PVModuleWattage
        };
      })
    )
    .subscribe(res => {
      this.informationCard = res;
    });

    this.SubscriptionProfile = this.siteService.getInformationProfile(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          D_LOG : map.response.D_LOG.details,
          stringInverter : map.response.stringInverter.details,
          centralizedInverter : map.response.centralizedInverter.details,
          weatherStation : map.response.weatherStation.details,
          meter : map.response.meter.details,
          dieselGenerator : map.response.PV_DGSync.isActive,
          D_LOGIsActive : map.response.D_LOG.isActive,
          stringInverterIsActive : map.response.stringInverter.isActive,
          centralizedInverterIsActive : map.response.centralizedInverter.isActive,
          weatherStationIsActive : map.response.weatherStation.isActive,
          meterIsActive : map.response.meter.isActive,
          dieselGeneratorIsActive : map.response.PV_DGSync.isActive,
        };
      })
    )
    .subscribe(res => {

      this.D_LOGIsActive = res.D_LOGIsActive;
      this.stringInverterIsActive = res.stringInverterIsActive;
      this.centralizedInverterIsActive = res.centralizedInverterIsActive;
      this.weatherStationIsActive = res.weatherStationIsActive;
      this.meterIsActive = res.meterIsActive;
      this.dieselGeneratorIsActive = res.dieselGeneratorIsActive;
    
      if(this.D_LOGIsActive){
        this.D_LOGProfileData = res.D_LOG;
        this.d_logSource = new MatTableDataSource<D_LOGProfile>(this.D_LOGProfileData);
        this.d_logSource.paginator = this.paginator1;
      }
      if(this.stringInverterIsActive){
        this.stringInverterProfileData = res.stringInverter;
        this.stringInverterSource = new MatTableDataSource<StringInverterProfile>(this.stringInverterProfileData);
        this.stringInverterSource.paginator = this.paginator2;
      }
      if(this.centralizedInverterIsActive){
        this.centralizedInverterProfileData = res.centralizedInverter;
        this.centralizedInverterSource = new MatTableDataSource<CentralizedInverterProfile>(this.centralizedInverterProfileData);
        this.centralizedInverterSource.paginator = this.paginator3;
      }
      if(this.weatherStationIsActive){
        this.weatherStationProfileData = res.weatherStation;
        this.weatherStationSource = new MatTableDataSource<WeatherStationProfile>(this.weatherStationProfileData);
        this.weatherStationSource.paginator = this.paginator4;
      }
      if(this.meterIsActive){
        this.meterProfileData = res.meter;
        this.meterSource = new MatTableDataSource<MeterProfile>(this.meterProfileData);
        this.meterSource.paginator = this.paginator5;
      }
      if(this.dieselGeneratorIsActive){
        this.dieselGeneratorProfileData = res.dieselGenerator;
        this.dieselGeneratorSource = new MatTableDataSource<DieselGeneratorProfile>(this.dieselGeneratorProfileData);
        this.dieselGeneratorSource.paginator = this.paginator6;
      }
     
    });
  }

  applyFilterD_Log(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.d_logSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterStringInverter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.stringInverterSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterCentralizedInverter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.centralizedInverterSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterWeatherStation(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.weatherStationSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterMeter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.meterSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterDieselGenerator(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dieselGeneratorSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.Subscription.unsubscribe();
    this.SubscriptionProfile.unsubscribe();
   }
}
