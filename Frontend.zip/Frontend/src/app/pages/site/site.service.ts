import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Subject, throwError, Observable, BehaviorSubject } from "rxjs";
import { Router, ActivatedRoute } from "@angular/router";

import { Response } from "./site.model";

@Injectable({ providedIn: "root" })
export class SiteService {
  
  private pathParamState = new Subject<string>();
  pathParam : Observable<string>;
  public siteId : string; 
  unsubAnalyticsComp = new Subject<any>();

  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) {
    this.pathParam = this.pathParamState.asObservable();
  }

  updatePathParamState(newPathParam:string){
   this.pathParamState.next(newPathParam);
  }
  
  async getSiteId () {
    await this.pathParam.subscribe( site => this.siteId=site );
    return this.siteId;
  }

  getSiteDevices(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/devices?username="
    +username+"&siteid="+siteId)
  }

  getSiteNavigation(username:string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/navigation?username="+username+"&siteid="+siteId)
  }

  getDashboardCard(username:string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/card?username="+username+"&siteid="+siteId)
  }

  getDashboardSiteLevelStatus(username:string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/status?username="+username+"&siteid="+siteId)
  }

  getDashboardCurve(username:string, siteId: string, period: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/curve?username="
    +username+"&siteid="+siteId+"&period="+period)
  }

  getAnalyticsCurve1(username:string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve1?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp)
  }

  getAnalyticsCurve2(username:string, siteId: string, period: string,timestamp: any): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve2?username="
    +username+"&siteid="+siteId+"&period="+period+"&timestamp="+timestamp)
  }
  getAnalyticsCurve3(username:string, siteId: string, timestamp: string, deviceId:string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve3?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp+"&deviceid="+deviceId)
  }

  getAnalyticsCurve4(username:string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve4?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp)
  }

  getStringInverterCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCard?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getStringInverterCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCurve?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getStringInverterParameter(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterParameter?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getCentralizedInverterCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/centralizedInverterCard?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getCentralizedInverterCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/centralizedInverterCurve?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getCentralizedInverterParameter(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/centralizedInverterParameter?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getWeatherStationCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/card?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getWeatherStationCurve1(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/Curve1?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getWeatherStationCurve2(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/Curve2?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getMeterCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/meter/Card?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getMeterCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/meter/Curve?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getMeterParameter(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/meter/Parameter?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId)
  }

  getPV_DGSyncCard(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/pv_dgsync/Card?username="
    +username+"&siteid="+siteId)
  }

  getPV_DGSyncStatus(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/pv_dgsync/Status?username="
    +username+"&siteid="+siteId)
  }

  getPV_DGSyncCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/pv_dgsync/Curve?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getPV_DGSyncAnalysisCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/pv_dgsync/AnalysisCurve?username="
    +username+"&siteid="+siteId+"&deviceid="+deviceId+"&timestamp="+timestamp)
  }

  getPV_DGSyncPowerThrottling(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/pv_dgsync/PowerThrottling?username="
    +username+"&siteid="+siteId)
  }

  getZeroExportCard(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/zeroexport/Card?username="
    +username+"&siteid="+siteId)
  }

  getZeroExportCurve(username: string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/zeroexport/Curve?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp)
  }

  getZeroExportAnalysisCurve(username: string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/zeroexport/AnalysisCurve?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp)
  }

  getGridImportExportCurve(username:string, siteId: string, period: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/zeroexport/gridimportexportcurve?username="
    +username+"&siteid="+siteId+"&period="+period)
  }

  getZeroExportPowerThrottling(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/zeroexport/PowerThrottling?username="
    +username+"&siteid="+siteId)
  }

  getAlarmDetail(username: string, siteId: string, device: string, state: string, timestamp: number): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/alarm/detail?username="
    +username+"&siteid="+siteId+"&device="+device+"&state="+state+"&timestamp="+timestamp)
  }

  getReportDaily(username: string, siteId: string, device: string, timestamp: string): Observable<Blob> {
    let uri = "http://www.holmiumtechnologies.com/beta/rms/api/report/daily?username="
    +username+"&siteid="+siteId+"&device="+device+"&timestamp="+timestamp;
    return this.http.get(uri, { responseType: 'blob' });
  }

  getReportDuration(username: string, siteId: string, timestamp1: string, timestamp2: string): Observable<Blob> {
    let uri = "http://www.holmiumtechnologies.com/beta/rms/api/report/duration?username="
    +username+"&siteid="+siteId+"&timestamp1="+timestamp1+"&timestamp2="+timestamp2;
    return this.http.get(uri, { responseType: 'blob' });
  }

  getEmailReportDaily(username: string, siteId: string, timestamp: string, email: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/report/dailyemailreport?username="
    +username+"&siteid="+siteId+"&timestamp="+timestamp+"&emailid="+email);
  }

  getInformationCard(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/information/card?username="
    +username+"&siteid="+siteId)
  }

  getInformationProfile(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/information/profile?username="
    +username+"&siteid="+siteId)
  }
}
