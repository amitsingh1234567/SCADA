import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, Observable, interval } from 'rxjs';

import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment} from 'moment';

import * as Highcharts from 'highcharts';
import Windbarb from 'highcharts/modules/windbarb';
import NoData from 'highcharts/modules/no-data-to-display';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
Windbarb(Highcharts);
NoData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { WeatherStationCard, WeatherStationIrradianceCurve, WeatherStationTemperatureCurve, WeatherStationWindCurve, WeatherStationRainCurve } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-weatherstation",
  templateUrl: "weatherstation.component.html",
  styleUrls: ['./weatherstation.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class WeatherStationComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;
  private subscriptionWeatherStationCard: Subscription;
  private subscriptionIrradianceCurve: Subscription;
  private subscriptionTemperatureCurve: Subscription;
  private subscriptionWindCurve: Subscription;
  private subscriptionRainCurve: Subscription;
  timer$ : Observable<number> = interval(60000);

  public username: string;
  public siteId: string;
  public devices = [];
  public selectedWeatherStation : string;

  public weatherStationCard : WeatherStationCard ={
    timestamp: '--',
    status: 'Offline',
    irradiance: '0 W/m2',
    cumulativeIrradiance: '0 kWh/m2',
    ambientTemperature: '0 °C',
    moduleTemperature: '0 °C',
    windSpeed: '0 m/s',
    windDirection: ' 0 Deg',
    relativeHumidity: '0 %',
    rainGauge: '0 cm'
  }

  public datePicker1 = new FormControl(moment());
  public datePicker2 = new FormControl(moment());
  public datePicker3 = new FormControl(moment());
  public datePicker4 = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public weatherStationIrradianceCurveData : WeatherStationIrradianceCurve ={
    time :[],
    GHI :[],
    GTI1 :[],
  }

  public weatherStationTemperatureCurveData : WeatherStationTemperatureCurve ={
    time :[],
    ambientTemperature :[],
    moduleTemperature1 :[]
  }

  public weatherStationWindCurveData : WeatherStationWindCurve ={
    time :[],
    windSpeedDirection: []
  }

  public weatherStationRainCurveData : WeatherStationRainCurve ={
    time :[],
    relativeHumidity: [],
    rainfall: []
  }

  highcharts = Highcharts;
  
  public irradianceCurveOption : any = {   
      chart: {
         type: "spline",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.weatherStationIrradianceCurveData.time
      },
      yAxis: [{ // Primary yAxis
        title: {
            text: 'Irradiance (W/m2)'
          },
        }],
      series: [{
        name: 'GHI',
        data: this.weatherStationIrradianceCurveData.GHI,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      },{
        name: 'GTI',
        data: this.weatherStationIrradianceCurveData.GTI1,
        color: '#F4B400',
        tooltip: {
        valueSuffix: ' W/m2'
        }
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: +5,
            y: -12
        }
      },
      plotOptions:{
        spline: {
          marker: {
              radius: 2,
              states: { hover: { radius: 5 } }
          },
        }
      },
  };

  public updateFlag1 : boolean = false;
  public oneToOneFlag1 : boolean = true;

  public temperatureCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.weatherStationTemperatureCurveData.time
    },
    yAxis: [{
      title: {
          text: 'Temperature (°C)'
        },
      }],
    series: [{
      name: 'Ambient Temp.',
      data: this.weatherStationTemperatureCurveData.ambientTemperature,
      color: '#DB6595',
      tooltip: {
      valueSuffix: ' °C'
      }
    },
    {
      name: 'Module Temp.',
      data: this.weatherStationTemperatureCurveData.moduleTemperature1,
      color: '#08A0A3',
      tooltip: {
        valueSuffix: ' °C'
        }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 2,
            states: { hover: { radius: 5 } }
        },
      }
    },
  };

  public updateFlag2 : boolean = false;
  public oneToOneFlag2 : boolean = true;

  public windCurveOption : any = {   
    chart: {
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.weatherStationWindCurveData.time
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Wind Speed (m/s)'
        },
      }],
    series: [{
      type: 'area',
      name: 'Wind Speed',
      data: this.weatherStationWindCurveData.windSpeed,
      color: '#4285F4',
      fillColor: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
              [0, '#4285F4'],
              [1, Highcharts.color('#4285F4')
                      .setOpacity(0.25).get()
              ]
          ]
      },
      tooltip: {
          valueSuffix: ' m/s'
      },
      states: {
          inactive: {
              opacity: 1
          }
      }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 2,
            states: { hover: { radius: 5 } }
        },
      }
    },
  };

  public updateFlag3 : boolean = false;
  public oneToOneFlag3 : boolean = true;

  public rainCurveOption : any = {   
    chart: {
       type: "column",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.weatherStationRainCurveData.time,
       crosshair: true
    },
    yAxis: [{
      title: {
          text: 'Relative Humidity (%)'
        },
      }, { // Secondary yAxis
      title: {
          text: 'Rainfall (mm)',
      },
      opposite: true
    }],
    series: [{
      name: 'Relative Humidity',
      data: this.weatherStationRainCurveData.relativeHumidity,
      color: '#6F60B8',
      tooltip: {
      valueSuffix: ' %'
      }
    },
    {
      name: 'Rainfall',
      yAxis:1,
      data: this.weatherStationRainCurveData.relativeHumidity,
      color: '#76C400',
      tooltip: {
        valueSuffix: ' mm'
        }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    // plotOptions: {
    //   column: {
    //       pointPadding: 0.2,
    //       borderWidth: 0
    //   }
    // }
  };

  public updateFlag4 : boolean = false;
  public oneToOneFlag4 : boolean = true;

constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}

  async ngOnInit() : Promise<void>  {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));

    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          devices:map.response.weatherStation
        };
      })
    )
    .subscribe(res => {
      res.devices.forEach(element => {
        this.devices.push({name:element.building+' '+element.name, id:element.id})
      });
      this.selectedWeatherStation = this.devices[0].id.toString();
      this.weatherStationCards();
      this.irradianceCurve();
      this.temperatureCurve();
      this.windCurve();
      this.rainCurve();
   });
  }

  weatherStationCards(){
    this.subscriptionWeatherStationCard = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getWeatherStationCard(this.username, this.siteId, this.selectedWeatherStation)),
      map(map => {
        return {
          timestamp: map.response.timestamp,
          status: map.response.status,
          irradiance: map.response.GTI,
          cumulativeIrradiance: map.response.cumulativeGTI,
          ambientTemperature: map.response.ambientTemperature,
          moduleTemperature: map.response.moduleTemperature,
          windSpeed: map.response.windSpeed,
          windDirection: map.response.windDirection,
          relativeHumidity: map.response.relativeHumidity,
          rainGauge: map.response.rainGauge
        };
      })
    )
    .subscribe(res => {
      this.weatherStationCard = res;
  });
  }

  irradianceCurve(){
    this.subscriptionIrradianceCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getWeatherStationCurve1(this.username, this.siteId, this.selectedWeatherStation,this.datePicker1.value)),
      map(map => {
        return {
          time: map.response.time,
          GHI : map.response.GHI,
          GTI1: map.response.GTI1,
          GTI2: map.response.GTI2,
          GTI3: map.response.GTI3,
          GTI4: map.response.GTI4,
          GTI5: map.response.GTI5
        };
      })
    )
    .subscribe(res => {
      this.weatherStationIrradianceCurveData = res;
      this.irradianceCurveOption.xAxis={
        categories:this.weatherStationIrradianceCurveData.time
      };

      this.irradianceCurveOption.series=[];

      if(this.weatherStationIrradianceCurveData.GHI)
      this.irradianceCurveOption.series[0]={
        name: 'GHI',
        data: this.weatherStationIrradianceCurveData.GHI,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };
     
      if(this.weatherStationIrradianceCurveData.GTI1)
      this.irradianceCurveOption.series[1]={
        name: 'GTI',
        data: this.weatherStationIrradianceCurveData.GTI1,
        color: '#F4B400',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };

      if(this.weatherStationIrradianceCurveData.GTI2)
      this.irradianceCurveOption.series[2]={
        name: 'GTI 1',
        data: this.weatherStationIrradianceCurveData.GTI2,
        color: '#EE2558',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };

      if(this.weatherStationIrradianceCurveData.GTI3)
      this.irradianceCurveOption.series[3]={
        name: 'GTI 2',
        data: this.weatherStationIrradianceCurveData.GTI3,
        color: '#1BB79A',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };

      if(this.weatherStationIrradianceCurveData.GTI4)
      this.irradianceCurveOption.series[4]={
        name: 'GTI 3',
        data: this.weatherStationIrradianceCurveData.GTI4,
        color: '#7CB5EC',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };

      if(this.weatherStationIrradianceCurveData.GTI5)
      this.irradianceCurveOption.series[5]={
        name: 'GTI 4',
        data: this.weatherStationIrradianceCurveData.GTI5,
        color: '#86C541',
        tooltip: {
        valueSuffix: ' W/m2'
        } 
      };
     
      this.updateFlag1=true;
      this.oneToOneFlag1 =true;
    });
  }

  temperatureCurve(){
    this.subscriptionTemperatureCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getWeatherStationCurve1(this.username, this.siteId, this.selectedWeatherStation,this.datePicker2.value)),
      map(map => {
        return {
          time: map.response.time,
          ambientTemperature: map.response.ambientTemperature,
          moduleTemperature1: map.response.moduleTemperature1,
          moduleTemperature2: map.response.moduleTemperature2,
          moduleTemperature3: map.response.moduleTemperature3,
          moduleTemperature4: map.response.moduleTemperature4,
          moduleTemperature5: map.response.moduleTemperature5
        };
      })
    )
    .subscribe(res => {
      this.weatherStationTemperatureCurveData = res;
      
      this.temperatureCurveOption.xAxis={
        categories:this.weatherStationTemperatureCurveData.time
      };

      this.temperatureCurveOption.series=[];

      if(this.weatherStationTemperatureCurveData.ambientTemperature)
      this.temperatureCurveOption.series[0]={
        name: 'Ambient Temp.',
        data: this.weatherStationTemperatureCurveData.ambientTemperature,
        color: '#DB6595',
        tooltip: {
        valueSuffix: ' °C'
        }
      };
     
      if(this.weatherStationTemperatureCurveData.moduleTemperature1)
      this.temperatureCurveOption.series[1]={
        name: 'Module Temp.',
        data: this.weatherStationTemperatureCurveData.moduleTemperature1,
        color: '#08A0A3',
        tooltip: {
          valueSuffix: ' °C'
        }
      };

      if(this.weatherStationTemperatureCurveData.moduleTemperature2)
      this.temperatureCurveOption.series[2]={
        name: 'Module Temp. 1',
        data: this.weatherStationTemperatureCurveData.moduleTemperature2,
        color: '#02B1F0',
        tooltip: {
          valueSuffix: ' °C'
        }
      };

      if(this.weatherStationTemperatureCurveData.moduleTemperature3)
      this.temperatureCurveOption.series[3]={
        name: 'Module Temp. 2',
        data: this.weatherStationTemperatureCurveData.moduleTemperature3,
        color: '#86C541',
        tooltip: {
          valueSuffix: ' °C'
        }
      };

      if(this.weatherStationTemperatureCurveData.moduleTemperature4)
      this.temperatureCurveOption.series[4]={
        name: 'Module Temp. 3',
        data: this.weatherStationTemperatureCurveData.moduleTemperature4,
        color: '#618AC4',
        tooltip: {
          valueSuffix: ' °C'
        }
      };

      if(this.weatherStationTemperatureCurveData.moduleTemperature5)
      this.temperatureCurveOption.series[4]={
        name: 'Module Temp. 4',
        data: this.weatherStationTemperatureCurveData.moduleTemperature5,
        color: '#2879A3',
        tooltip: {
          valueSuffix: ' °C'
        }
      };

      this.updateFlag2=true;
      this.oneToOneFlag2 =true;
    });
  }

  windCurve(){
    this.subscriptionWindCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getWeatherStationCurve2(this.username, this.siteId, this.selectedWeatherStation,this.datePicker3.value)),
      map(map => {
        return {
          time: map.response.time,
          windSpeed: map.response.windSpeed,
          windDirection: map.response.windDirection,
        };
      })
    )
    .subscribe(res => {
      this.weatherStationWindCurveData = res;
      
      this.windCurveOption.xAxis={
        categories:this.weatherStationWindCurveData.time,
      };

      this.windCurveOption.series=[];

      if(this.weatherStationWindCurveData.windSpeed && this.weatherStationWindCurveData.windDirection)
      {
        this.weatherStationWindCurveData.windSpeedDirection=[];
        
        for(let i=0;i<this.weatherStationWindCurveData.windSpeed.length;i++)
        {
          this.weatherStationWindCurveData.windSpeedDirection.push([this.weatherStationWindCurveData.windSpeed[i],this.weatherStationWindCurveData.windDirection[i]]);
        }
        
        this.windCurveOption.xAxis={
          categories:this.weatherStationWindCurveData.time,
          offset: 40
        };

        this.windCurveOption.series=[{
          type: 'area',
          name: 'Wind Speed',
          keys: ['y', 'rotation'], // rotation is not used here
          data: this.weatherStationWindCurveData.windSpeedDirection,
          color: '#4285F4',
          fillColor: {
              linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
              stops: [
                  [0, '#4285F4'],
                  [1, Highcharts.color('#4285F4')
                          .setOpacity(0.25).get()
                  ]
              ]
          },
          tooltip: {
              valueSuffix: ' m/s'
          },
          states: {
              inactive: {
                  opacity: 1
              }
          }
        },{
          type:"windbarb",
          name: 'Wind Direction',
          data: this.weatherStationWindCurveData.windSpeedDirection,
          color: '#F58731',
          tooltip: {
          valueSuffix: ' m/s'
          } 
        }];
      }
      else if(this.weatherStationWindCurveData.windSpeed && !this.weatherStationWindCurveData.windDirection)
      {
        this.windCurveOption.xAxis={
          categories:this.weatherStationWindCurveData.time,
        };

        this.windCurveOption.series=[{
          type: 'area',
          name: 'Wind Speed',
          data: this.weatherStationWindCurveData.windSpeed,
          color: '#4285F4',
          fillColor: {
              linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
              stops: [
                  [0, '#4285F4'],
                  [1, Highcharts.color('#4285F4')
                          .setOpacity(0.25).get()
                  ]
              ]
          },
          tooltip: {
              valueSuffix: ' m/s'
          },
          states: {
              inactive: {
                  opacity: 1
              }
          }
        }];
      }
      // else if(!this.weatherStationWindCurveData.windSpeed && !this.weatherStationWindCurveData.windDirection)
      // {}
  
      this.updateFlag3=true;
      this.oneToOneFlag3 =true;
    });
  }

  rainCurve(){
    this.subscriptionRainCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getWeatherStationCurve2(this.username, this.siteId, this.selectedWeatherStation,this.datePicker4.value)),
      map(map => {
        return {
          time: map.response.time,
          relativeHumidity: map.response.relativeHumidity,
          rainfall: map.response.rainGauge
        };
      })
    )
    .subscribe(res => {
      this.weatherStationRainCurveData = res;
      
      this.rainCurveOption.xAxis={
        categories:this.weatherStationRainCurveData.time
      };

      this.rainCurveOption.series=[];

      if(this.weatherStationRainCurveData.relativeHumidity)
      this.rainCurveOption.series[0]={
        name: 'Relative Humidity',
        data: this.weatherStationRainCurveData.relativeHumidity,
        color: '#6F60B8',
        tooltip: {
        valueSuffix: ' %'
        }
      };
     
      if(this.weatherStationRainCurveData.rainfall)
      this.rainCurveOption.series[1]={
        name: 'Rainfall',
        yAxis:1,
        data: this.weatherStationRainCurveData.rainfall,
        color: '#76C400',
        tooltip: {
          valueSuffix: ' mm'
        }
      };

      this.updateFlag4=true;
      this.oneToOneFlag4 =true;
    });

  }

  changeWeatherStation(){
    this.subscriptionWeatherStationCard.unsubscribe();
    this.subscriptionIrradianceCurve.unsubscribe();
    this.subscriptionTemperatureCurve.unsubscribe();
    this.subscriptionRainCurve.unsubscribe();
    this.weatherStationCards();
    this.irradianceCurve();
    this.temperatureCurve();
    this.rainCurve();
  }

  changeDatePicker1(event: MatDatepickerInputEvent<Date>){
    this.subscriptionIrradianceCurve.unsubscribe();
    this.irradianceCurve();
  }

  changeDatePicker2(event: MatDatepickerInputEvent<Date>){
    this.subscriptionTemperatureCurve.unsubscribe();
    this.temperatureCurve();
  }

  changeDatePicker3(event: MatDatepickerInputEvent<Date>){
    this.subscriptionWindCurve.unsubscribe();
    this.windCurve();
  }

  changeDatePicker4(event: MatDatepickerInputEvent<Date>){
    this.subscriptionRainCurve.unsubscribe();
    this.rainCurve();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
    this.subscriptionWeatherStationCard.unsubscribe();
    this.subscriptionIrradianceCurve.unsubscribe();
    this.subscriptionTemperatureCurve.unsubscribe();
    this.subscriptionWindCurve.unsubscribe();
    this.subscriptionRainCurve.unsubscribe();
   }
}
