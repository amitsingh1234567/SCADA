import { Component, OnInit,OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { takeUntil, map } from 'rxjs/operators';

// import { ErrorStateMatcher } from '@angular/material/core';
import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, ErrorStateMatcher, ShowOnDirtyErrorStateMatcher } from '@angular/material/core';

import swal from "sweetalert2";

import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment, Moment} from 'moment';

import { ReportDevice } from '../site.model';
import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-report",
  templateUrl: "report.component.html",
  styleUrls: ['./report.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})


export class ReportComponent implements OnInit, OnDestroy {

  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;



  public datePicker1 = new FormControl(moment());
  public datePicker2 = new FormControl(moment().subtract(6, 'days'));
  public datePicker3 = new FormControl(moment());
  public datePicker5 = new FormControl(moment());
  
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  maxDate1 = moment();
  minDate1 = moment("01/01/2019", "MM-DD-YYYY");

  maxDate2 = moment();
  minDate2 = moment("01/01/2019", "MM-DD-YYYY");

  public username: string;
  public siteId: string;
  public devices : ReportDevice = {
    "Site Analysis" : true
  };
  public selectedDevice : string = "Site Analysis";
  public isLoading = false;
  public isLoading1 = false;
  public isLoading2  = false;
  //public isLoading3  = false;
  
  constructor(private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {
  }
  
  async ngOnInit() : Promise<void>  {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteNavigation(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          "String Inverter": map.response.stringInverter,
          "Centralized Inverter": map.response.centralizedInverter,
          "Weather Station": map.response.weatherStation,
          "Meter": map.response.meter,
          "PV-DG Sync": map.response.PV_DGSync,
          "Zero Export": map.response.zeroExport
        };
      })
    )
    .subscribe(res => {
      this.devices["String Inverter"] = res["String Inverter"];
      this.devices["Centralized Inverter"] = res["Centralized Inverter"];
      this.devices["Weather Station"] = res["Weather Station"];
      this.devices["Meter"] = res["Meter"];
      this.devices["PV-DG Sync"] = res["PV-DG Sync"];
      this.devices["Zero Export"] = res["Zero Export"];
   });
  }

  changeDatePicker1(event: MatDatepickerInputEvent<Date>){
    this.datePicker1.setValue(event.value)
  }

  changeDatePicker2(event: MatDatepickerInputEvent<Date>){
    this.datePicker2.setValue(event.value);
    
    let date = moment(event.value).add(30, 'days');
    let dateNow = moment();
    
    if(dateNow.diff(date, 'days') >= 0)
    {
      this.maxDate2 = moment(event.value).add(30, 'days');
      this.datePicker3.setValue(moment(event.value).add(30, 'days'));
    }
    else
    {
      this.maxDate2 = moment();
      this.datePicker3.setValue(moment());
    }
  }

  changeDatePicker3(event: MatDatepickerInputEvent<Date>){
    this.datePicker3.setValue(event.value);
    this.minDate2 = moment("01/01/2019", "MM-DD-YYYY");

    let date = moment(this.datePicker2.value);
    let dateNow = moment(event.value);
    
    if(dateNow.diff(date, 'days') < 0)
    {
      this.maxDate1 = moment(this.datePicker3.value);
      this.datePicker2.setValue(moment(this.datePicker3.value));
    }
  }

  changeDatePicker5(event: MatDatepickerInputEvent<Date>){
    this.datePicker5.setValue(event.value)
  }

  ReportDaily()
  {
    this.isLoading = true;
    this.siteService.getReportDaily(this.username, this.siteId, this.selectedDevice, this.datePicker1.value)
    .subscribe(x => {
      // It is necessary to create a new blob object with mime-type explicitly set
      // otherwise only Chrome works like it should
      var newBlob = new Blob([x], { type: "application/xlsx" });

      // IE doesn't allow using a blob object directly as link href
      // instead it is necessary to use msSaveOrOpenBlob
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob);
          return;
      }

      // For other browsers: 
      // Create a link pointing to the ObjectURL containing the blob.
      const data = window.URL.createObjectURL(newBlob);

      var link = document.createElement('a');
      link.href = data;

     // let dateName = new Date(this.datePicker1.value);
      link.download = "DailyReport.xlsx";
      this.isLoading = false;
      // this is necessary as link.click() does not work on the latest firefox
      link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

      setTimeout(function () {
          // For Firefox it is necessary to delay revoking the ObjectURL
          window.URL.revokeObjectURL(data);
          link.remove();
      }, 100);
  });
    swal.fire({
      title: 'Success',
      text: 'Please wait for a while.',
      type: 'success',
      timer: 5000,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-success'
    });
  
  
  }

  ReportDuration()
  {
    this.isLoading1 = true;
    this.siteService.getReportDuration(this.username, this.siteId, this.datePicker2.value, this.datePicker3.value)
    .subscribe(x => {
      // It is necessary to create a new blob object with mime-type explicitly set
      // otherwise only Chrome works like it should
      var newBlob = new Blob([x], { type: "application/xlsx" });

      // IE doesn't allow using a blob object directly as link href
      // instead it is necessary to use msSaveOrOpenBlob
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob);
          return;
      }

      // For other browsers: 
      // Create a link pointing to the ObjectURL containing the blob.
      const data = window.URL.createObjectURL(newBlob);

      var link = document.createElement('a');
      link.href = data;

     // let dateName = new Date(this.datePicker1.value);
      link.download = "DurationReport.xlsx";
      this.isLoading1 = false;
      // this is necessary as link.click() does not work on the latest firefox
      link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

      setTimeout(function () {
          // For Firefox it is necessary to delay revoking the ObjectURL
          window.URL.revokeObjectURL(data);
          link.remove();
      }, 100);
    });
    swal.fire({
      title: 'Success',
      text: 'Please wait for a while.',
      type: 'success',
      timer: 5000,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-success'
    });
  }
  
  EmailReportDaily(form: NgForm) {
    if(form.invalid)
      return;
    
    swal.fire({
      title: 'Info',
      text: 'Please wait for a while.',
      type: 'info',
      timer: 2000,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-info'
    });

    this.isLoading2 = true;
    this.siteService.getEmailReportDaily(this.username, this.siteId, this.datePicker5.value, form.value.email)
    .pipe(
      map(map => {
        return {
          status : map.response
        };
      })
    )
    .subscribe(arg => {
      this.isLoading2 = false;
      if(arg.status == 'Email Send Successfully')
      {
        swal.fire({
            title: 'Success',
            text: 'Email Send Successfully',
            type: 'success',
            timer: 2000,
            buttonsStyling: false,
            confirmButtonClass: 'btn btn-success'
          });
      }
      else
      {
        swal.fire({
          title: 'Failed',
          text: 'Email Sending Failed. Please Try Again.!!',
          type: 'error',
          timer: 2000,
          buttonsStyling: false,
          confirmButtonClass: 'btn btn-error'
        });
      }
    });
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
  }
}
