import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { interval, Observable, Subject, Subscription } from 'rxjs';

import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment, Moment} from 'moment';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { PV_DGSyncCard, DGStatus, PV_DGSyncCurve, PV_DGSyncAnalysisCurve, PowerThrottlingStatus } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-pv-dgsync",
  templateUrl: "pv-dgsync.component.html",
  styleUrls: ['./pv-dgsync.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class PV_DGSyncComponent implements OnInit, OnDestroy {

  private destroy = new Subject<void>();
  private subscriptionDevices : Subscription;
  private subscriptionCard: Subscription;
  private subscriptionStatus: Subscription;
  private subscriptionCurve1: Subscription;
  private subscriptionCurve2: Subscription;
  private subscriptionPowerThrottling: Subscription;

  timer$ : Observable<number> = interval(60000);
  timer1$ : Observable<number> = interval(300000);
  // timer1$ : Observable<number> = interval(900000);

  public username: string;
  public siteId: string;
  public datePicker1 = new FormControl(moment());
  public datePicker2 = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public PV_DGSyncCardData : PV_DGSyncCard ={};
  public DGStatusData : DGStatus[] = [];
  public DGColumns: string[] = ['name', 'capacity', 'status', 'load', 'timestamp'];
  dgSource = new MatTableDataSource<DGStatus>(this.DGStatusData);
  @ViewChild('paginator1') paginator1: MatPaginator;
  
  public dgDevices = [];
  public selectedDG = new FormControl();

  public dgMeterDevices = [];
  public selectedDGMeter : string;

  public selectedParameter = "1";

  public PV_DGSyncCurveData : PV_DGSyncCurve = {
    timestamp: []
  };

  highcharts = Highcharts;

  public pv_dgSyncCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.PV_DGSyncCurveData.timestamp
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Output Power (kW)'
        },
      }],
    series: [],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 3,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };
 
  public pv_dgSyncUpdateFlag : boolean = false;
  public pv_dgSyncOneToOneFlag  : boolean = false;

  public PV_DGSyncAnalysisCurveData : PV_DGSyncAnalysisCurve = {
    timestamp: []
  };

  public pv_dgSyncAnalysisCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.PV_DGSyncAnalysisCurveData.timestamp
    },
    yAxis: [],
    series: [],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 3,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };
 
  public pv_dgSyncAnalysisUpdateFlag : boolean = true;
  public pv_dgSyncAnalysisOneToOneFlag  : boolean = true;

  public powerThrottlingData: PowerThrottlingStatus[] = [];
  public displayedColumns: string[] = ['name', 'capacity', 'throttledCapacity', 'timestamp'];
  public dataSource = new MatTableDataSource<PowerThrottlingStatus>(this.powerThrottlingData);
  @ViewChild('paginator2') paginator2: MatPaginator;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}

  async ngOnInit() : Promise<void> {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          DG:map.response.PV_DGSync,
          DGMeter:map.response.dgMeter,
        };
      })
    )
    .subscribe(res => {
      res.DG.forEach(element => {
        this.dgDevices.push({name: element.name, id:element.id})
      });
      res.DGMeter.forEach(element => {
        this.dgMeterDevices.push({name: element.name, id:element.id})
      });
      
      this.selectedDG.setValue([this.dgDevices[0].id.toString()]);
      this.selectedDGMeter = this.dgMeterDevices[0].id.toString();
      this.pv_dgSyncCurve();
      this.pv_dgSyncAnalysisCurve();
    });  
    this.pv_dgSyncCards();
    this.dgStatus();
    this.powerThrottlingStatus();
  }

  ngAfterViewInit() {
    this.dgSource.paginator = this.paginator1;
    this.dataSource.paginator = this.paginator2;
  }

  pv_dgSyncCards(){
    this.subscriptionCard= this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getPV_DGSyncCard(this.username, this.siteId)),
      map(map => {
        return {
          pv_dgSyncStatus: map.response.pv_dgSyncStatus,
          totalUserLoad:map.response.totalUserLoad,
          dgLoad: map.response.dgLoad,
          solarLoad: map.response.solarLoad,
          dailyDGYield: map.response.dgEnergy,
          dailySolarYield: map.response.solarEnergy,
        };
      })
    )
    .subscribe(res => {
      this.PV_DGSyncCardData = res;
  });
  }

  dgStatus(){
    this.subscriptionStatus= this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getPV_DGSyncStatus(this.username, this.siteId)),
      map(map => {
        return {
          status: map.response,
        };
      })
    )
    .subscribe(res => {
      this.DGStatusData = res.status;
      this.dgSource = new MatTableDataSource<DGStatus>(this.DGStatusData);
      this.dgSource.paginator = this.paginator1;
  });
  }

  pv_dgSyncCurve(){
    this.subscriptionCurve1 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getPV_DGSyncCurve(this.username, this.siteId, this.selectedDG.value, this.datePicker1.value)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      
      this.PV_DGSyncCurveData = res['res'];

      this.pv_dgSyncCurveOption.series=[];
      
      for (let entries of Object.entries(this.PV_DGSyncCurveData)) {
        
        if(entries[0] == 'timestamp')
        {
          this.pv_dgSyncCurveOption.xAxis={
            categories:this.PV_DGSyncCurveData.timestamp
          };
        }
        else
        {
          this.pv_dgSyncCurveOption.series.push({
            name: entries[0],
            data: entries[1],
            tooltip: {
            valueSuffix: ' kW'
            }
          });
        }
      }

      this.pv_dgSyncUpdateFlag= true;
      this.pv_dgSyncOneToOneFlag = true;
      
    });
  }

  pv_dgSyncAnalysisCurve(){
    this.subscriptionCurve2 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getPV_DGSyncAnalysisCurve(this.username, this.siteId, this.selectedDGMeter, this.datePicker2.value)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      
      this.PV_DGSyncAnalysisCurveData = res['res'];
    
      this.pv_dgSyncAnalysisCurveOption.xAxis=[];
      this.pv_dgSyncAnalysisCurveOption.yAxis=[];
      this.pv_dgSyncAnalysisCurveOption.series=[];

      this.pv_dgSyncAnalysisCurveOption.xAxis.push({
        categories:this.PV_DGSyncAnalysisCurveData.timestamp
      });

      if(this.selectedParameter == '1')
      { 
        this.pv_dgSyncAnalysisCurveOption.yAxis.push({ // Primary yAxis
          title: {
              text: 'Total Export Yield (kWh)'
            },
          },{
            title: {
              text: 'Daily Export Yield (kWh)'
            },
            opposite: true
        });

        this.pv_dgSyncAnalysisCurveOption.series.push(
          {
            name: 'Total Yield',
            data: this.PV_DGSyncAnalysisCurveData.activeEnergyExport,
            color:'#F44350',
            tooltip: {
            valueSuffix: ' kWh'
            }
          },{
            name: 'Daily Yield',
            data: this.PV_DGSyncAnalysisCurveData.todayActiveEnergyExport,
            color:'#139AEE',
            yAxis:1,
            tooltip: {
            valueSuffix: ' kWh'
            }
          });
      }
      else if(this.selectedParameter == '2')
      { 
        this.pv_dgSyncAnalysisCurveOption.yAxis.push({ 
          title: {
              text: 'Power (kW)'
            },
          }
        );

        this.pv_dgSyncAnalysisCurveOption.series[0]=
          {
            name: 'Power Phase R',
            data: this.PV_DGSyncAnalysisCurveData.activePowerPhaseR,
            color:'#F44350',
            tooltip: {
            valueSuffix: ' kW'
            }
          };

          this.pv_dgSyncAnalysisCurveOption.series[1]=
          {
            name: 'Power Phase Y',
            data: this.PV_DGSyncAnalysisCurveData.activePowerPhaseY,
            color:'#7169E3',
            tooltip: {
            valueSuffix: ' kW'
            }
          };

        this.pv_dgSyncAnalysisCurveOption.series[2]=
          {
            name: 'Power Phase B',
            data: this.PV_DGSyncAnalysisCurveData.activePowerPhaseB,
            color:"#139AEE",
            tooltip: {
            valueSuffix: ' kW'
            }
          };
      }
      else if(this.selectedParameter == '3')
      { 
        this.pv_dgSyncAnalysisCurveOption.yAxis.push(
          { 
          title: {
              text: 'Voltage (V)'
            },
          }
        );
        this.pv_dgSyncAnalysisCurveOption.series.push(
          {
            name: 'Voltage Phase R',
            data: this.PV_DGSyncAnalysisCurveData.voltagePhaseR,
            tooltip: {
            valueSuffix: ' V'
            }
          },
          {
            name: 'Voltage Phase Y',
            data: this.PV_DGSyncAnalysisCurveData.voltagePhaseY,
            tooltip: {
            valueSuffix: ' V'
            }
          },
          {
            name: 'Voltage Phase B',
            data: this.PV_DGSyncAnalysisCurveData.voltagePhaseB,
            color:"#7169E3",
            tooltip: {
            valueSuffix: ' V'
            },
          }
          );
      }
      else if(this.selectedParameter == '4')
      {
        this.pv_dgSyncAnalysisCurveOption.yAxis.push(
          { 
            title: {
                text: 'Current (A)'
              }
          }
        );
        this.pv_dgSyncAnalysisCurveOption.series.push(
          {
            name: 'Current Phase R',
            data: this.PV_DGSyncAnalysisCurveData.currentPhaseR,
            color:"#F1DF00",
            tooltip: {
            valueSuffix: ' A'
            }
          },
          {
            name: 'Current Phase Y',
            data: this.PV_DGSyncAnalysisCurveData.currentPhaseY,
            color:"#2DCE89",
            tooltip: {
            valueSuffix: ' A'
            }
          },
          {
            name: 'Current Phase B',
            data: this.PV_DGSyncAnalysisCurveData.currentPhaseB,
            color:"#F9AA42",
            tooltip: {
            valueSuffix: ' A'
            },
          }
          );
      }

      this.pv_dgSyncAnalysisUpdateFlag= true;
      this.pv_dgSyncAnalysisOneToOneFlag = true;
      
    });
  }
  
  powerThrottlingStatus(){
    this.subscriptionPowerThrottling= this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getPV_DGSyncPowerThrottling(this.username, this.siteId)),
      map(map => {
        return {
          status: map.response,
        };
      })
    )
    .subscribe(res => {
      this.powerThrottlingData = res.status;
      this.dataSource = new MatTableDataSource<PowerThrottlingStatus>(this.powerThrottlingData);
      this.dataSource.paginator = this.paginator2;
  });
  }
  
  changeDG()
  {
    this.subscriptionCurve1.unsubscribe();
    this.pv_dgSyncCurve();
  }

  changeDGMeter()
  {
    this.subscriptionCurve2.unsubscribe();
    this.pv_dgSyncAnalysisCurve();
  }

  changeParameter()
  {
    this.subscriptionCurve2.unsubscribe();
    this.pv_dgSyncAnalysisCurve();
  }

  changeDatePicker1(event: MatDatepickerInputEvent<Date>)
  {
    this.datePicker1.setValue(event.value)
    this.subscriptionCurve1.unsubscribe();
    this.pv_dgSyncCurve();
  }

  changeDatePicker2(event: MatDatepickerInputEvent<Date>)
  {
    this.datePicker2.setValue(event.value)
    this.subscriptionCurve2.unsubscribe();
    this.pv_dgSyncAnalysisCurve();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionCard.unsubscribe();
    this.subscriptionStatus.unsubscribe();
    this.subscriptionDevices.unsubscribe();
    this.subscriptionCurve1.unsubscribe();
    this.subscriptionCurve2.unsubscribe();
    this.subscriptionPowerThrottling.unsubscribe();
   }
}
