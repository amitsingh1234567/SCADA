import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";

import { AuthLayoutComponent } from "./layouts/auth-layout/auth-layout.component";
import { OutlineLayoutComponent } from "./layouts/outline-layout/outline-layout.component";
import { SiteLayoutComponent } from "./layouts/site-layout/site-layout.component";
import { AuthGuard } from './pages/auth/authGuard';
import { AdminComponent } from "./pages/admin/admin.component";
import { ResetPasswordComponent } from "./pages/auth/reset-password/reset-password.component";
import { ForgetPasswordComponent } from "./pages/auth/forget-password/forget-password.component";
import { PlantProfileComponent } from "./pages/plant-profile/plant-profile.component";
import { UpdatePlantProfileComponent } from "./pages/plant-profile/update-plant-profile/update-plant-profile.component";
import { PlantListComponent } from "./pages/plant-profile/plant-list/plant-list.component";


const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full"
  },
  {
    path: 'admin',
    component: AdminComponent
  },
  {
    path: 'plantList',
    component: PlantListComponent
  },
  {
    path: 'insert/plantProfile',
    component: PlantProfileComponent
  },
  {
    path: 'update/plantProfile/:id',
    component: PlantProfileComponent
  },
  {
    path: 'all/plantProfile',
    component: UpdatePlantProfileComponent
  },
  {
    path: 'reset-password',
    component: ForgetPasswordComponent
  },
  {
    path: 'reset-password/:token',
    component: ResetPasswordComponent
  },
  {
    path: "login",
    component: AuthLayoutComponent,
    children: [
      {
        path: "",
        loadChildren:  "./layouts/auth-layout/auth-layout.module#AuthLayoutModule"
      }]
  },
  {
    path: "outline",
    component: OutlineLayoutComponent,
    children: [
      {
        path: "",
        loadChildren: "./pages/outline/outline.module#OutlineModule",
        canActivate: [AuthGuard]
      }
    ]
  },
  {
    path: "site",
    component: SiteLayoutComponent,
    children: [
	    {
        path: ":id",
        loadChildren: "./pages/site/site.module#SiteModule",
        canActivate: [AuthGuard]
      },
    ]
  },
  {
    path: "**",
    redirectTo: "/outline/overview",
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes, {
      useHash: false,
      enableTracing: false
    })
  ],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule {}
