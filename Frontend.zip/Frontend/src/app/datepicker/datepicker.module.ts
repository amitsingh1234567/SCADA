import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatMomentDateModule } from '@angular/material-moment-adapter';

import { Datepicker1Component } from "./datePicker1/datepicker1.component";
import { Datepicker2Component } from "./datePicker2/datepicker2.component";
import { Datepicker3Component } from "./datePicker3/datepicker3.component";
import { RouterModule } from '@angular/router';
// import { RouterModule } from "@angular/router";
// import { CollapseModule } from "ngx-bootstrap/collapse";
// import { DxVectorMapModule } from "devextreme-angular";
// import { BsDropdownModule } from "ngx-bootstrap";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatTabsModule,
    MatMomentDateModule,
    RouterModule,
    // CollapseModule.forRoot(),
    // DxVectorMapModule,
    // PerfectScrollbarModule,
    // BsDropdownModule.forRoot()
  ],
  declarations: [
    Datepicker1Component,
    Datepicker2Component,
    Datepicker3Component
  ],
  exports: [
    Datepicker1Component,
    Datepicker2Component,
    Datepicker3Component
  ],
})
export class DatepickerModule {}
