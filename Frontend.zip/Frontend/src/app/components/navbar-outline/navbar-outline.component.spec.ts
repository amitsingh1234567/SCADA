import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { NavbarOutlineComponent } from "./navbar-outline.component";

describe("NavbarOutlineComponent", () => {
  let component: NavbarOutlineComponent;
  let fixture: ComponentFixture<NavbarOutlineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NavbarOutlineComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarOutlineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});