import { Component, OnInit, ElementRef, OnDestroy } from "@angular/core";
import { Subscription } from 'rxjs/internal/Subscription';
import { map, catchError } from "rxjs/operators";

import { AuthService } from 'src/app/pages/auth/auth.service';

import { OutlineService } from '../../pages/outline/outline.service';
import { User } from '../../pages/outline/outline.model'

@Component({
  selector: "app-navbar-outline",
  templateUrl: "./navbar-outline.component.html",
  styleUrls: ["./navbar-outline.component.scss"]
})
export class NavbarOutlineComponent implements OnInit, OnDestroy {
  
  private username: string;
  public user : User = 
  {
    clientName:'',
    clientLogo:"assets/img/brand/client.png",
    plants:[]
  };
  private Subscription:Subscription;

  constructor( public authService:AuthService, public outlineService: OutlineService) {
   
  }
  
  ngOnInit() {
    this.username = this.authService.getUsername();
    this.Subscription = this.outlineService.getUserProfile(this.username)
    .pipe(
      map(map => {
        return {
          clientName:map.response.clientName,
          clientLogo:map.response.clientLogo,
          plants:map.response.plants
        };
      })
    )
    .subscribe(res => {
      this.user = res;
    });
  }

  onLogout(){
    this.authService.logout();
  }
  
  ngOnDestroy() {
    this.Subscription.unsubscribe();
  }
  
}