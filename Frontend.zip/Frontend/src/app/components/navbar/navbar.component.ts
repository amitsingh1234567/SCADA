import { Component, OnInit, ElementRef } from "@angular/core";
import { Router, ActivatedRoute, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from "@angular/common";
import { Subscription, Observable, interval } from 'rxjs';
import { map, startWith, switchMap } from 'rxjs/operators';

import { AuthService } from '../../pages/auth/auth.service';
import { SiteService } from '../../pages/site/site.service';
import { ComponentsService } from '../components.service';

export interface User {
  clientName: String,
  clientLogo: String
}

@Component({
  selector: "app-navbar",
  templateUrl: "./navbar.component.html",
  styleUrls: ["./navbar.component.scss"]
})

export class NavbarComponent implements OnInit {
  
  public location: Location;
  public path: string;
  public pageName: string;
  sidenavOpen: boolean = true;
  userIsAuthenticated: boolean = false;
  public username: string
  public user: User = 
  {
    clientName:'',
    clientLogo:"assets/img/brand/client.png"
  };
  public siteId: string;
  public siteName: string = "SiteName";
  public alarmsQuantity = 0;
  public alarmsQuantityFlag = false;
  public alarms = [];

  private Subscription:Subscription;
  private SubscriptionSiteName:Subscription;
  private SubscriptionAlarmNotification:Subscription;
  private authListenerSubs: Subscription;
  timer$ : Observable<number> = interval(60000);
  
  constructor(
    location: Location,
    private element: ElementRef,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private siteService: SiteService,
    private componentsService: ComponentsService
  ) {
    this.location = location;
    this.router.events.subscribe((event: Event) => {
       if (event instanceof NavigationStart) {
          // Show loading indicator
       }
       if (event instanceof NavigationEnd) {
          // Hide loading indicator
          this.path = location.path();
         
          if(this.path.includes('dashboard')) {
            this.pageName = "Dashboard";
          }
          else if (this.path.includes('analytics')) {
            this.pageName = "Analytics";
          }
          else if (this.path.includes('stringinverter')) {
            this.pageName = "String Inverter";
          }
          else if (this.path.includes('centralizedinverter')) {
            this.pageName = "Centralized Inverter";
          }
          else if (this.path.includes('weatherstation')) {
            this.pageName = "Weather Station";
          }
          else if (this.path.includes('meter')) {
            this.pageName = "Meter";
          }
          else if (this.path.includes('pv-dgsync')) {
            this.pageName = "PV-DG Sync";
          }
          else if (this.path.includes('zeroexport')) {
            this.pageName = "Zero Export";
          }
          else if (this.path.includes('alarm')) {
            this.pageName = "Alarm";
          }
          else if (this.path.includes('report')) {
            this.pageName = "Report";
          }
          else if (this.path.includes('calendar')) {
            this.pageName = "Calendar";
          }
          else if (this.path.includes('information')) {
            this.pageName = "Information";
          }
         
          if (window.innerWidth < 1200) {
            document.body.classList.remove("g-sidenav-pinned");
            document.body.classList.add("g-sidenav-hidden");
            this.sidenavOpen = false;
          }
       }

       if (event instanceof NavigationError) {
           // Hide loading indicator

           // Present error to user
           console.log(event.error);
       }
   });
  // console.log(this.path);

  }

  async ngOnInit() : Promise<void>{
   
    this.authListenerSubs = this.authService.getAuthStatusListener().subscribe(isAuthenticated => {
      this.userIsAuthenticated =isAuthenticated;
    });
    this.username = this.authService.getUsername();
    this.Subscription = this.componentsService.getUserProfile(this.username)
    .pipe(
      map(map => {
        return {
          clientName:map.response.clientName,
          clientLogo:map.response.clientLogo
        };
      })
    )
    .subscribe(res => {
      this.user.clientName = res.clientName;
      this.user.clientLogo = res.clientLogo;
    });

    this.siteId= await this.siteService.getSiteId();
    this.SubscriptionSiteName = this.componentsService.getSiteNavigation(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          siteName: map.response.siteName
        };
      })
    )
    .subscribe(res => {
      this.siteName = res.siteName;
    });
    this.SubscriptionAlarmNotification = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.componentsService.getAlarmNotification(this.username, this.siteId)),
      map(map => {
        return {
          alarms: map.response.alarms
        };
      })
    )
    .subscribe(res => {
      this.alarms=[];
      this.alarmsQuantity= res.alarms.length;
      if(this.alarmsQuantity>0)
      this.alarmsQuantityFlag = true;
      res.alarms.forEach(element => {
        this.alarms.push({deviceName:element.deviceName, status:element.operatingState, duration:element.duration})
      });
    })
  }

  onLogout(){
    this.authService.logout();
  }
  
  ngOnDestroy(){
    this.authListenerSubs.unsubscribe();
    this.Subscription.unsubscribe();
    this.SubscriptionSiteName.unsubscribe();
    this.SubscriptionAlarmNotification.unsubscribe();
  }

  onMouseLeaveSidenav() {
    if (!document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-show");
    }
  }
  
  openSidebar() {
    if (document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-pinned");
      document.body.classList.add("g-sidenav-hidden");
      this.sidenavOpen = false;
    } else {
      document.body.classList.add("g-sidenav-pinned");
      document.body.classList.remove("g-sidenav-hidden");
      this.sidenavOpen = true;
    }
  }
  toggleSidenav() {
    if (document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-pinned");
      document.body.classList.add("g-sidenav-hidden");
      this.sidenavOpen = false;
    } else {
      document.body.classList.add("g-sidenav-pinned");
      document.body.classList.remove("g-sidenav-hidden");
      this.sidenavOpen = true;
    }
  }
}
