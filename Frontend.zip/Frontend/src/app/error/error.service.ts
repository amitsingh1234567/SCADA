import { Subject } from "rxjs";
import { Injectable } from "@angular/core";
import { ToastrService, IndividualConfig } from 'ngx-toastr';

@Injectable({ providedIn: "root" })
export class ErrorService {

constructor(private toastr: ToastrService) {}

  private errorListener = new Subject<string>();

  getErrorListener() {
    return this.errorListener.asObservable();
  }

  throwError(message: string) {
    this.errorListener.next(message);
    this.toastr.show(
        "<span class='alert-icon ni ni-bell-55' data-notify='icon'></span> <div class='alert-text'</div> <span class='alert-title' data-notify='title'>Alert</span> <span data-notify='message'>"+message+'</span></div>',
        "",
        {
          timeOut: 8000,
          closeButton: true,
          enableHtml: true,
          tapToDismiss: false,
          titleClass: "alert-title",
          positionClass: "toast-top-center",
          toastClass:
            "ngx-toastr alert alert-dismissible alert-default alert-notify"
        }
      );
      console.log(message);
  }

  handleError() {
    this.errorListener.next(null);
  }
}
